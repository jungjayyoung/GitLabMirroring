package e2_simulation.q7;

import java.io.*;
import java.util.*;

//Main_bj_18406_럭키스트레이트
public class 럭키스트레이트_김태현 {
	public static void main(String[] args) throws Exception {
//		System.setIn(new FileInputStream("res/input_ect_12_7.txt"));
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		char[] ch = in.readLine().toCharArray();
		int[] score = new int[ch.length];
		for(int i=0;i<ch.length;i++) {
			score[i] = ch[i] - '0';
		}
		
		int lsum = 0, rsum = 0;
		for(int i=0;i<score.length/2;i++) {
			lsum += score[i];
		}
		for(int i=score.length/2;i<score.length;i++) {
			rsum += score[i];
		}
		
		if(lsum == rsum) {
			System.out.println("LUCKY");
		}else {
			System.out.println("READY");
		}
	}
}

/*
123402
7755

LUCKY
READY
*/