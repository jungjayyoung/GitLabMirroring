package com.ssafy.ws.step3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

public class BookManagerImpl implements IBookManager {

	private static final int MAX_SIZE = 100;
	private List<Book> books = new ArrayList<>(MAX_SIZE); // NullPointerException 이 나오지 않게 객체를 생성해야 한다!!
	
	private static IBookManager instance = new BookManagerImpl();
	
	private BookManagerImpl() {
		loadData();
	}
	
	public static IBookManager getInstance() {
		return instance;
	}
	
	
	@Override
	public void add(Book book) throws DuplicatedException {

		try {
			searchByIsbn(book.getIsbn());
			throw new DuplicatedException(book.getIsbn()+ "중복");
		} catch (ISBNNotFoundException e) {
			books.add(book);
		}
	}

	@Override
	public void remove(String isbn) throws ISBNNotFoundException {
		Book b = searchByIsbn(isbn);
		books.remove(b); // List는  Object 삭제
		
	}

	@Override
	public Book[] getList() {
		return books.toArray(new Book[0]); // ArrayList 사이즈 만큼 리스트로 반환해준다. 0 그냥 쓰면 된다.
	}

	@Override
	public Book searchByIsbn(String isbn) throws ISBNNotFoundException {
		
		for(Book b: books) {
			if(b.getIsbn().equals(isbn)) return b;
		}
		throw new ISBNNotFoundException(isbn);
	}

	@Override
	public Book[] searchByTitle(String title) {
		List<Book> tmp = new ArrayList<>();
		
		for(Book b:books) {
			if(b.getTitle().contains(title)) tmp.add(b);
			
		}

		return tmp.toArray(new Book[0]); // ArrayList 사이즈 만큼 리스트로 반환해준다. 0 그냥 쓰면 된다.
	}

	@Override
	public Book[] getBooks() {
		List<Book> tmp = new ArrayList<>();
		for(Book b:books) {
			if(!(b instanceof Magazine)) tmp.add(b);
			
		}
		return tmp.toArray(new Book[0]); // ArrayList 사이즈 만큼 리스트로 반환해준다. 0 그냥 쓰면 된다.
	}

	@Override
	public Magazine[] getMagazines() {
		List<Book> tmp = new ArrayList<>();
		
		for(Book b:books) {
			if(b instanceof Magazine) tmp.add(b);
			
		}

		return tmp.toArray(new Magazine[0]); // ArrayList 사이즈 만큼 리스트로 반환해준다. 0 그냥 쓰면 된다.
	}

	@Override
	public int getTotalPrice() {
		int total = 0;
		
		for(Book b: books) {
			total += b.getPrice();
		}
		return total;
	}

	@Override
	public double getPriceAvg() {
		return (double)getTotalPrice()/books.size();
	}

	@Override
	public void buy(String isbn, int quantity) throws ISBNNotFoundException {
		Book b = searchByIsbn(isbn);
		b.setQuantity(b.getQuantity()-quantity);

	}

	@Override
	public void sell(String isbn, int quantity) throws ISBNNotFoundException, QuantityException {
		Book b = searchByIsbn(isbn);
		int r = b.getQuantity() - quantity;
		if(r <0) throw new QuantityException();
		b.setQuantity(r);
	}

	@Override
	public void saveData() {
		try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("book.dat"));) {
			oos.writeObject(books);
			oos.flush();
			System.out.println("[SYSTEM] 파일 쓰기 성공");
		} catch (Exception e) {
			System.out.println("[SYSTEM] 파일 쓰기 성공");
			e.printStackTrace();
		}

	}
	
private void loadData() {
		
		File f =new File("book.dat");
		if(f.exists()) {
			try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));){
				books = (List<Book>)ois.readObject();			//NULLPointerException 발생 !!!! 로컬 변수가 아닌 기존 변수를 사용한다.
				// 대입을 해줘야 한다.
				System.out.println("[SYSTEM] 파일 읽기 성공");
			} catch (Exception e) {
				System.out.println("[SYSTEM] 파일 읽기 실패");
				e.printStackTrace();
			}
			
		}
		
	}

}
