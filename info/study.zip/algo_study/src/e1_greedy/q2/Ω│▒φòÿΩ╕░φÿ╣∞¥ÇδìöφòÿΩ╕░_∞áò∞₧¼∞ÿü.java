import java.io.*;
import java.util.*;

public class q2 {

	public static void main(String[] args) throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		String s = br.readLine();
		
		int sum = s.charAt(0) -'0';
		
		for(int i=1; i< s.length();i++) {
			if(sum == 0) {
				sum += s.charAt(i) -'0';
			}else {
				if(s.charAt(i) == '0' || s.charAt(i) == '1') {
					sum += s.charAt(i) - '0';
				}else {
					sum *= s.charAt(i) - '0';
				}
			}
		}
		
		System.out.print(sum);
		
	}

}
