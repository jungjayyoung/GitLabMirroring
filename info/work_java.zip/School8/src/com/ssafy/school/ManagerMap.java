package com.ssafy.school;

import java.util.Arrays;
import java.util.List;
import java.util.Vector;

public class ManagerMap implements IManager {

	
	private List<Person> pa;
	
	//2
	private static IManager instance = new ManagerMap();
	
	//3
	public static IManager getInstance() {
		return instance;
	}
	
	private ManagerMap(int size) {
		pa = new Vector<>(size);
	}
	
	public  ManagerMap() {
		
	}
	@Override
	public void add(Person p) {
		pa.put(p.getName(),p);
	}
	
	@Override
	public Person[] search() {
		return pa.toArray(new Person[0]);
	}
	
	@Override
	public Person search(String name) {
		return pa.get(name);
	}
	
	@Override
	public void update(Person p) {
		Person t = search(p.getName());
		if( t!= null) pa.set(pa.indexOf(t), p);
	}
	
	@Override
	public void delete(String name) {
		Person p = search(name);
		if( p!= null) pa.remove(p);
	}
	
	@Override
	public void printAll() {
		for(Person p: pa) p.printAll();
	}
	
}
