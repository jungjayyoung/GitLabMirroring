window.onload = function () {
  // localStorage에서 poll이름의 data 얻기.
  var user = localStorage.getItem("user");
  // 유저가 보여질 div 리스트
  var userDivList = document.querySelectorAll(".user_info");

  // localStorage에서 얻은 문자열을 JSON객체로 변환.

  var user_info = JSON.parse(user);
  console.log(userDivList);
  var id = user_info.id; // 유저 아이디
  var password = user_info.password; // 유저 패스워드
  var name = user_info.name; // 유저 이름
  var address = user_info.address; // 유저 주소
  var tel = user_info.tel; // 유저 전화번호

  for (var i = 0; i < userDivList.length; i++) {
    var userContent = "";
    if (i == 0) {
      userDivList[i].innerHTML = '<input type="text" value=' + id + " />";
    } else if (i == 1) {
      userDivList[i].innerHTML = '<input type="text" value=' + password + " />";
    } else if (i == 2) {
      userDivList[i].innerHTML = '<input type="text" value=' + name + " />";
    } else if (i == 3) {
      userDivList[i].innerHTML = '<input type="text" value=' + address + " />";
    } else if (i == 4) {
      userDivList[i].innerHTML = '<input type="text" value=' + tel + " />";
    }
  }

  // 투표 화면 구성.
  // var pollContent = '<div class="vote_title">[ 당신의 선택 ]</div>';
  // pollContent += '<div class="vote_question">' + question + "</div>";
  // pollContent += '<div class="vote_answer">';
  // pollContent += "  <ul>";
  // for (var i = 0; i < answers.length; i++) {
  //   pollContent += "<li>";
  //   pollContent += "    <label>";
  //   pollContent +=
  //     '      <input type="radio" name="vote_answer" value="' + answers[i] + '" />' + answers[i];
  //   pollContent += "    </label>";
  //   pollContent += "  </li >";
  // }
  // pollContent += "</ul>";
  // pollContent += "</div>";
  // pollContent += '<div class="vote_button">';
  // pollContent +=
  //   '  <button class="button btn_primary" onclick="javascript:poll();">투표하기</button>';
  // pollContent += '  <button class="button">결과보기</button>';
  // pollContent += "</div>";
  // pollContent +=
  //   '<div class="vote_date">투표기간 : ' +
  //   dateFormat(sdate) +
  //   " ~ " +
  //   dateFormat(edate) +
  //   "</div>";
  // 투표 화면에 투표양식 추가.
  // pollDiv.innerHTML = pollContent;
};
