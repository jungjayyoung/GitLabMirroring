import java.sql.*;



public class JdbcTest1_select {

	public static void main(String[] args) throws Exception{
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		String sql ="select * from regions where region_id=?";
		Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/ssafydb?serverTimezone=UTC", "ssafy", "ssafy");
		PreparedStatement ps = con.prepareStatement(sql);
		
		ps.setInt(1, 3);
		ResultSet rs = ps.executeQuery();
		
		while(rs.next()) {
			System.out.println(rs.getInt("region_id")+ " "+ rs.getString(2));
		}
		
		rs.close();
		ps.close();
		con.close();
	}
}
