package com.ssafy.school;

public class Person {

	private String name = "아무개";
	private int age;

	public Person(String name, int age) {
		setName(name);
		setAge(age);
	}
	public Person(String name) {
		this(name,99);
	}
	public Person() {
		this("모지리",99);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	private void checkAge(int age) {
		if(age < 1 || age > 99) {
			System.out.println("invalid age(1~99): " + age);
			System.exit(0);
		}else {
			this.age = age;			
		}
	}

	public void setAge(int age) {
		this.checkAge(age);
	}
	
	public void printAll() {
		System.out.println(getName()+ "\t" + getAge());
		
		
	}
	// 4-3 to-string
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Person [name=").append(name).append(", age=").append(age).append("]");
		return builder.toString();
	}
	
	
	
	
	

}