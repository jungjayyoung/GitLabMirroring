package com.ssafy.live3.inter.module;

public interface Printer {
    void print(String fileName);
}
