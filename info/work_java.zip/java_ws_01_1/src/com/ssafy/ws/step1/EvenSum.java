package com.ssafy.ws.step1;

import java.util.Scanner;

public class EvenSum {

	public static void main(String[] args) {

		System.out.println("코드를 작성하세요.");
		Scanner sc = new Scanner(System.in);
		
		System.out.println("숫자 입력 >> ");
		int num = sc.nextInt();
		int sum = 0;
		for(int i = 1; i<=num;i++) {
			if(i % 2 == 0) {
				sum += i;
			}
		}
		
		System.out.println("1부터 "+ num + "까지의 수  중 짝수의 합 = " + sum);
		
		
	}

}
