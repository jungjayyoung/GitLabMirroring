package com.ssafy.live3.abs;

public class HorseCart extends Vehicle{

	@Override
	public void addFuel() {
		System.out.println("말은 건초를 먹인다."); 
		
	}
	
}
