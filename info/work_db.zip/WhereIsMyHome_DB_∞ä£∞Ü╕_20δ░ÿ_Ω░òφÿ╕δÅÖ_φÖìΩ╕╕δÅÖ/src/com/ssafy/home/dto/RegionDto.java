package com.ssafy.home.dto;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class RegionDto {
	
	private int id;
	private String name;
	
}
