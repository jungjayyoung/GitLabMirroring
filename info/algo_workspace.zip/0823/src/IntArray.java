import java.io.*;
import java.util.*;



public class IntArray {

	public static void main(String[] args) throws IOException{
		
		
	}

}
