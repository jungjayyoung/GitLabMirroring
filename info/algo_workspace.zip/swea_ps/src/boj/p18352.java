package boj;

import java.io.*;
import java.util.*;


public class p18352 {
	
	

	public static void main(String[] args) throws IOException{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st;
		
		
	}

}
