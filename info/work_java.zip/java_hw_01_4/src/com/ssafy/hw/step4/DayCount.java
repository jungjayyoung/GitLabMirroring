package com.ssafy.hw.step4;

import java.util.Scanner;

import com.sun.xml.internal.ws.api.message.saaj.SAAJFactory;

public class DayCount {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("월과 일을 입력하세요.");
		
		int mon,day;
		int [] mth = new int [] {0,31,28,31,30,31,30,31,31,30,31,30,31};
		
		
		mon = sc.nextInt();
		day = sc.nextInt();
		int a = 1;
		int b = 1;
		int ans = 1;
		while(a != mon || b != day) {

			b++;
			ans++;
			if(b > mth[a]) {
				b = 1;
				a++;
			}
		}
		
		System.out.println(ans);
		
	}

}
