package com.ssafy.live3.inter.replace;

public interface Calculator {
    int add(int a, int b);
  }

