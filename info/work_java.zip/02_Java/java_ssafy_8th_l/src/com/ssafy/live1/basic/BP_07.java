package com.ssafy.live1.basic;

public class BP_07 {
    public static void main(String[] args) {
        int i1 = Integer.MAX_VALUE;
        
        int i2 = i1+1;
        
        System.out.println(i2);
    }
}
