import java.sql.*;



public class JdbcTest3_update {

	public static void main(String[] args) throws Exception{
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		String sql ="update regions set region_name=? where region_id = ?";
		Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/ssafydb?serverTimezone=UTC", "ssafy", "ssafy");
		PreparedStatement ps = con.prepareStatement(sql);
		
		ps.setString(1, "Happy");
		ps.setInt(2, 5);
		int r = ps.executeUpdate();
		System.out.println("변경완료"+ r);
		
		
		
		ps.close();
		con.close();
	}
}
