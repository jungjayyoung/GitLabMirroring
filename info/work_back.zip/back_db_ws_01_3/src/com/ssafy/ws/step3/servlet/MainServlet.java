package com.ssafy.ws.step3.servlet;

// 이 서블릿이 호출되기 위해서는 url 상에 http://server_ip:port/context_name/main 이 필요하다.

public class MainServlet{
	//코드를 작성하세요
}
