use world;

select curdate() "오늘", dayofyear(curdate()) "올해 지난 날", date_add(curdate(), interval 100 day) "100일 후";

select curdate() from dual; -- from dual 생략가능
select now(), sysdate();
select curtime();
-- now는 호출할 때의 시간이고 sysdate는 실행할 때의 시간을 리턴한다.
select sysdate(), sleep(2), sysdate();
select now(), sleep(2), now();


-- 주관식 단답형으로 나온다. case when then 구문
select name, continent, LifeExpectancy,
	case when LifeExpectancy > 80 then '장수 국가'
    when LifeExpectancy > 60 then '일반 국가'
    else '단명 국가'
end "구분"
from country
where continent = 'asia'
and LifeExpectancy is not null
order by LifeExpectancy;

select name, gnp, gnpold, ifnull((gnp-gnpold),"신규") "gnp 향상"
from country
order by name;

-- weekday() Mon =0, Tue = 1... Sun = 6;
-- dayofweek() Mon = 2, Tue = 3, ... Sat = 7, Sun = 1;

select weekday('2020-05-05'),
	case when weekday('2020-05-05') = 5 or weekday('2020-05-05') = 6 then '불행'
		else '행복'
	end "행복 여부";
    
select weekday('2020-05-05'), if(weekday('2020-05-05') > 4,'불행','행복');

-------------------    
    
select count(*) "전체", count(IndepYear) "독립 인도 보유"
from country where IndepYear is not null;

-- 주관식 서술형 mysql 집계함수 종류 다 써라 count,sum, avg, max, min
select sum(LifeExpectancy) "합계", round(avg(LifeExpectancy),2) "평균", max(LifeExpectancy) "최대", min(LifeExpectancy) "최소"
from country;

select continent, count(*) "국가 수", sum(Population) "인구 합"
from country
group by continent
order by count(*) desc;

select continent, sum(SurfaceArea) "표면적 합"
from country
group by continent
order by sum(SurfaceArea) desc
limit 3;

select continent, sum(gnp) "gnp 합"
from country
where Population >= 50000000
group by continent
order by sum(gnp) asc;

select continent, sum(gnp) "gnp 합"
from country
where Population >= 50000000
group by continent
having sum(gnp) >= 5000000;

select indepyear, count(*) "독립 국가 수"
from country
group by indepyear
having count(*) >= 10;


# 12. country에서 국가 별로 gnp와 함께 전세계 평균 gnp, 대륙 평균 gnp를 출력하시오.(239건)

-- 윈도우 function 컬럼에 기본 집계 값을 보여주고 싶을 때 사용하며 된다.
-- avg() over(), over(partition by 칼럼명): 보여주고 싶은 데이터와 관련된 집계함수 아무거나 쓰면 된다
select continent, name, gnp,
avg(gnp) over() "전세계 평균",
avg(gnp) over(partition by continent) "대륙 평균"
from country;