package coding.implementation;
import java.io.*;

public class Solution_Q9_문자열압축_이하림 {

	public static int solution(String c) {
		String s = c;
		
		int minLen = s.length(); //압축했을 때 가장 짧은 문자열 길이
		StringBuilder temp = new StringBuilder();; //i길이만큼 잠시 저장하는 문자열
		String prev = null; //바로 직전 i길이 만큼의 문자열
		StringBuilder compress = new StringBuilder(); //압축 완료 문자열
		
		for(int i=1; i<= s.length() ; i++) { //각 압축 길이별로 반복
			prev = s.substring(0,i);  //맨 처음 i 길이만큼의 문자열                                                                                                               
			int cnt = i-1;
			int total = 1;
			for(int j=i; j < s.length(); j++) {

				temp.append(s.charAt(j));	
				cnt--;	
				if(cnt < 0) { //같은 길이만큼 끊었을 때
					if(temp.toString().equals(prev)){ //이전의 문자열과 같다면
						total++; //압축
						temp.setLength(0);
						cnt = i-1;
					}
					else {
						if(total != 1) compress.append(total).append(prev); //이전의 문자열과 같지 않다면
						else compress.append(prev);
						total = 1;
						prev = temp.toString();
					}
					temp.setLength(0); //초기화
					cnt = i-1;
					
					continue;
				}
						
			}
			//System.out.println(compress);
			if(total > 1) {
				if(temp.length() != 0) compress.append(total).append(prev).append(temp);
				else compress.append(total).append(prev);
			}
			else if(temp.length() != 0) compress.append(prev).append(temp);
			else compress.append(prev);
			
			prev = null;
			temp.setLength(0);
			minLen = Math.min(minLen, compress.length());
			compress.setLength(0);
			
		}
		return minLen;	
	}
	
	public static void main(String[] args) {
		System.out.println(solution("werwerwsdgsdfsdfsdf"));
	}
}
