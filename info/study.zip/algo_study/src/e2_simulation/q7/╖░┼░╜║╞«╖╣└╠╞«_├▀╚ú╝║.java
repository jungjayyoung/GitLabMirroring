package 럭키스트레이트;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Comparator;

public class 럭키스트레이트_추호성 {

	public static void main(String[] args) throws Exception{
		BufferedReader bf = new BufferedReader(new FileReader("C:\\SSAFY\\algo_study\\2_구현_기출\\src/문자열재정렬/문자열재정렬.txt"));
		String str = bf.readLine();
		int res = 0;
		ArrayList<Character> list = new ArrayList<Character>();

		for (int i = 0; i < str.length(); i++) {
			char at = str.charAt(i);
			if (48 <= at && at <= 58)
				res += (at - '0');

			else
				list.add(at);
		}
		list.sort(Comparator.naturalOrder());

		for (int i = 0; i < list.size(); i++)
			System.out.printf("%c", list.get(i));

		System.out.println(res);

		bf.close();

	}

}
