package day8;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.List;

public class UnserializeTest {

	public static void main(String[] args) {
		
		try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("phone.ser"));){
			
			
			List<Phone> pl = (List<Phone>)ois.readObject();
			for(Phone p: pl) {
				System.out.println(p);
			}
			System.out.println();
		}catch(IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
}
