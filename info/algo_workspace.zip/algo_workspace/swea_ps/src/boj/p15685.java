package boj;

import java.io.*;
import java.util.*;



public class p15685 {

	static int n;
	static int board[][] = new int[101][101];
	static List<int []> gen;
	static int dx[] = {-1,0,1,0};
	static int dy[] = {0,1,0,-1};
	
	
	public static void main(String[] args) throws IOException{
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st;
		
		
		n = Integer.parseInt(br.readLine());
		
		
		for(int i = 0; i < n; i++) {
			
			st = new StringTokenizer(br.readLine()," ");
			int xx,yy,d,g;
			gen = new ArrayList<int[]>();
			
			xx = Integer.parseInt(st.nextToken());
			yy = Integer.parseInt(st.nextToken());
			d = Integer.parseInt(st.nextToken());
			g = Integer.parseInt(st.nextToken());
			
			gen.add(new int[] {xx,yy,d}); // 먼저 좌표와 방향을 집어넣는다.
			
			
			//세대 만큼 돌린다.
			int nextx,nexty;
			for(int j = 0; j<=g; j++) {
				//nextx = 
				
			
			}
			
			
		}

	}

}
