import java.util.List;

// 기상청 날씨누리 https://www.weather.go.kr
public class WeatherMain{
	public static void main(String[] args) {
		WeatherDAOSAX dao=WeatherDAOSAX.getInstance();
//		WeatherDAODOM dao=WeatherDAODOM.getInstance();
		dao.connectXML();
		List<Weather> list=dao.getWeatherList();
		for(Weather w:list){
			System.out.println(w);
		}
	}
}
