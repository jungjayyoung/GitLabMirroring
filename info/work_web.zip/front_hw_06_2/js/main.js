window.onload = function () {
  if (!document.querySelector(".content-user-list")) return;

  const xhr = new XMLHttpRequest();
  const method = "GET";
  const url = "data/user.json";

  xhr.open(method, url);
  xhr.setRequestHeader("Content-Type", "application/text");

  xhr.onreadystatechange = function () {
    if (xhr.readyState === xhr.DONE) {
      if (xhr.status === 200) {
        const resJson = JSON.parse(xhr.responseText);
        const userData = resJson.users;
        let userList = document.querySelector(".content-user-list");
        for (let i = 0; i < userData.length; i++) {
          let carItem = `
            <div class="col-5">
              <div class="card border-danger mb-3 ms-4 me-4 position-relative">
                <div class="row g-0">
                  <div class="col-md-4 mt-2 ps-2 mb-2">
                    <img src="${userData[i]["img"]}" class="img-fluid rounded-start" alt="..." />
                  </div>
                  <div class="col-md-8 mt-5">
                    <div class="card-body">
                      <h5 class="card-title">${userData[i]["id"]}</h5>
                      <h6>${userData[i]["name"]}</h6>
                      <h6>${userData[i]["email"]}</h6>
                      <h6 class="mb-3">${userData[i]["age"]} 세</h6>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            `;
          userList.innerHTML += carItem;
        }
      }
    }
  };

  xhr.send();
};

function regist() {
  let id = document.getElementById("id").value;
  let password = document.getElementById("password").value;
  let name = document.getElementById("name").value;
  let email = document.getElementById("email").value;
  let age = document.getElementById("age").value;

  if (!id || !password || !name || !email || !age) {
    alert("빈칸이 없도록 입력해주세요.");
    return;
  } else {
    const user = {
      id: id,
      password: password,
      name: name,
      email: email,
      age: age,
    };

    localStorage.setItem("user", JSON.stringify(user));
    alert("사용자 등록 성공!");
    window.location.replace("login.html");
  }
}

function login() {
  let id = document.getElementById("id").value;
  let password = document.getElementById("password").value;

  const user = JSON.parse(localStorage.getItem("user"));

  if (
    user.id &&
    user.password &&
    user.id === id &&
    user.password === password
  ) {
    alert("로그인 성공 !");
    window.location.replace("index.html");
  } else {
    alert("로그인 실패 !");
  }
}
