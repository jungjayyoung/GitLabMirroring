package com.ssafy.hello;

import java.io.IOException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/world")
public class WorldServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

//    public WorldServlet() {
//        System.out.println("WorldServlet()");
//    }

	@Override
	public void init() throws ServletException {
		System.out.println("init()");
	}
	
	@Override
	public void destroy() {
		System.out.println("destroy()");
	}
	
//	@Override
//	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		System.out.println("service()");
//		super.service(request, response);
//	}
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doGet()");
		process(request, response);
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doPost()");
		request.setCharacterEncoding("UTF-8");
		process(request, response);
	}
	
	private void process(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		System.out.println("process()");
		String action = request.getParameter("action");
		System.out.println("action=["+action+"]");
		switch (action) {
		case "login":
			login(request, response);
			break;
		case "logout":
			logout(request, response);
			break;
		case "regist":
			regist(request, response);
			break;
		}
	}
	private void login(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		request.getRequestDispatcher("/hello.jsp").forward(request,response);
	}
	private void logout(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		//response.sendRedirect("http://www.naver.com/");
		response.sendRedirect(request.getContextPath() + "/world.jsp");
	}
	private void regist(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	
}
