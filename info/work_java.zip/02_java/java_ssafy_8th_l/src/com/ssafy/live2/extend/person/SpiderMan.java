package com.ssafy.live2.extend.person;

public class SpiderMan extends Person{
	boolean isSpider;
	Spider spider = new Spider();
	
	public SpiderMan(String name, boolean isSpider) {
		super(name);
		this.isSpider = isSpider;
	}
	
	public void fireWeb() {
		if(isSpider) {
			spider.firWeb();
		}
		else {
			System.out.println("사람일때는 참자");	
		}
	}
	
	void jump(){
		if(isSpider) {
			spider.jump();
		}else {
//			System.out.println("두다리로 폴짞!");
			super.jump();
		}
	}
	
	void love() {
		System.out.println("메리제인 사랑한다");
	}
	
	@Override
	public String toString() {
		return super.toString() + ", isSpider : "+isSpider;
	}
}
