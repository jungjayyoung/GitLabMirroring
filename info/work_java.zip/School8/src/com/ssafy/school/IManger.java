package com.ssafy.school;

public interface IManger {

	void add(Person p);
	Person[] search();
	Person search(String name);
	void update(Person p);
	void delete(String name);
	void printAll();

}