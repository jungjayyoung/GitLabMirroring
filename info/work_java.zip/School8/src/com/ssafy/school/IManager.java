package com.ssafy.school;

public interface IManager {

	void add(Person p) throws DuplicatedException;

	Person[] search();

	Person search(String name) throws NotFoundException;

	void update(Person p) throws NotFoundException;

	void delete(String name) throws NotFoundException;

	void printAll();

}