package com.ssafy.ws.step3.dto;

public class Book {
	//코드를 작성하세요
}
