package e2_simulation.q8;

import java.io.*;
import java.util.*;

public class 문자열재정렬_김태현 {
	public static void main(String[] args) throws Exception {
//		System.setIn(new FileInputStream("res/input_ect_12_8.txt"));
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

		char[] ch = in.readLine().toCharArray();
		int sum = 0, index = 0;
		for(int i=0;i<ch.length;i++) {
			if(ch[i] >= '0' && ch[i] <= '9') {
				sum += ch[i] - '0';
				ch[i] = '\u0000';

			}else {
				ch[index++] = ch[i];
			}
		}
		
		Arrays.sort(ch,0,index);
		
		for(int i=0;i<index;i++) {
			System.out.print(ch[i]);
		}
		System.out.println(sum);
		
		in.close();
	}
}

/*
K1KA5CB7
AJKDLSI412K4JSJ9D

ABCKK13
ADDIJJJKKLSS20
*/
