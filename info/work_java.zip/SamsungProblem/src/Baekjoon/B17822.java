package Baekjoon;

public class B17822 {

}
