package com.ssafy.ws.step3;

import java.util.Arrays;

/**
 * 도서리스트를 배열로 유지하며 관리하는 클래스
 */
public class BookManager {
	private static int MAX_SIZE=100;
	private Book[] books=new Book[MAX_SIZE];
	private int size;
	
	private static BookManager instance = new BookManager();
	private BookManager() {}
	public static BookManager getInstance() {
		return instance;
	}
	
	
	
	public void add(Book book) {
		books[size++] = book;
	}
	public void remove(String isbn) {
		for(int i = 0; i < size; i++) {
			
			if(books[i].getIsbn().equals(isbn)) {
				books[i] = books[--size];
				books[size] = null;
				return;
			}
			
		}

	}
	public Book[] getList() {
		//return Arrays.copyOfRange(books, 0, size);
		return Arrays.copyOf(books, size);
	}
	public Book searchByIsbn(String isbn) {
		for(int i = 0; i < size; i++) {
			
			if(books[i].getIsbn().equals(isbn)) {
				return books[i];
			}
			
		}
		return null;
	}
	//-----------------------//
	
	public Book[] searchByTitle(String title) {
		Book[] tmp = new Book[size];
		int cnt =0;
		for(int i = 0; i < size; i++) {
			
			if(books[i].getTitle().contains(title)) {
				tmp[cnt++] = books[i];
			}
			
		}
		return Arrays.copyOf(tmp, cnt);
	}
	
	public Magazine[] getMagazines() {
		Magazine[] tmp = new Magazine[size];
		int cnt =0;
		for(int i = 0; i < size; i++) {
			
			if(books[i] instanceof Magazine) {
				tmp[cnt++] = (Magazine)books[i];
			}
			
			
		}
		return Arrays.copyOf(tmp, cnt);
	}
	
	public Book[] getBooks() {
		Book[] tmp = new Book[size];
		int cnt =0;
		for(int i = 0; i < size; i++) {
			
			if(!(books[i] instanceof Magazine)) {
				tmp[cnt++] = books[i];
			}
			
		}
		return Arrays.copyOf(tmp, cnt);
	}
	
	public int getTotalPrice() {
		
		int total = 0;
		for(int i = 0; i< size; i++) {
			
			total += books[i].getPrice();
			
		}
		
		return total;
		
	}
	
	public double getPriceAvg() {
		
		return getTotalPrice()/(double)size;
	}
}
