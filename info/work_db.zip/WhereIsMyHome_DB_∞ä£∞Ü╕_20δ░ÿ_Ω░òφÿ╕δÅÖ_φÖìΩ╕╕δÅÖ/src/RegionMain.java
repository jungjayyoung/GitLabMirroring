package com.ssafy.home;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.home.dto.RegionDto;
import com.ssafy.home.service.RegionService;
import com.ssafy.home.service.RegionServiceImpl;

public class RegionMain{
	public static void main(String[] args) throws SQLException{
		RegionService svc=RegionServiceImpl.getInstance();
		
		System.out.println("*** Regions 전체 ***");
		for(RegionDto dto:svc.selectAll()) System.out.println(dto);
		System.out.println();
		
		System.out.println("*** Regions 등록 ***");
		RegionDto to=new RegionDto(5, "Ssafy");
		svc.insert(to);
		for(RegionDto dto:svc.selectAll()) System.out.println(dto);
		System.out.println();
		
		System.out.println("*** Regions 조회 ***");
		System.out.println(svc.select(5));
		System.out.println();
		
		System.out.println("*** Regions 변경 ***");
		to.setName("Happy");
		svc.update(to);
		for(RegionDto dto:svc.selectAll()) System.out.println(dto);
		System.out.println();
		
		System.out.println("*** Regions 삭제 ***");
		svc.delete(5);
		for(RegionDto dto:svc.selectAll()) System.out.println(dto);
		System.out.println();
	}
}
