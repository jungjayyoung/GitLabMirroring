package coding.greedy;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main_Q3_문자열뒤집기_이하림 {
	
	/**   백준 1439번     **/
	public static void main(String[] args) throws IOException {
		
		BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
		char[] s = bf.readLine().toCharArray();
		
		int[] cnt = new int[2];
		int prev = s[0]-'0';
		for(int i=1; i< s.length; i++) {
			if(prev != s[i]-'0') {
				cnt[prev]++;
				prev = s[i]-'0';
			}
		}
		cnt[prev]++;
		
		System.out.print(Math.min(cnt[0], cnt[1]));
	}
}
