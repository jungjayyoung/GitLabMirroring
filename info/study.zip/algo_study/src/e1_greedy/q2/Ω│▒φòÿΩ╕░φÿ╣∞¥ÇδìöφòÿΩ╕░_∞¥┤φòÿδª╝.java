package codingbook.greedy;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main_Q2_곱하기혹은더하기_이하림 {

	public static void main(String[] args) throws IOException {
		
		BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
		char[] s = bf.readLine().toCharArray();
		
		int result = s[0] - '0';
		int prev = s[0] - '0';
		for(int i=1; i<s.length;i++) {
			if(s[i-1]-'0' != 0 && s[i-1]-'0' != 1)
				result *= s[i] -'0';
			else result += s[i]-'0';
		}
		System.out.println(result);

	}

}
