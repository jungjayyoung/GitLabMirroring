package com.ssafy.live3.inter.relation;


public class Phone {

}
