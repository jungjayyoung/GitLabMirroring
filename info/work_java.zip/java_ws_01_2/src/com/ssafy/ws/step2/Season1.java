package com.ssafy.ws.step2;
import java.util.*;
public class Season1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		for(int i=0; i< 3; i++) {
			System.out.println("월 입력 >>");
			int num = sc.nextInt();
			
			if(num >= 3 && num <= 5) {
				System.out.println(num + "월은 봄입니다.");
				
			}
			if(num >= 6 && num <= 8) {
				System.out.println(num + "월은 여름입니다.");
				
			}
			if(num >= 9 && num <= 11) {
				System.out.println(num + "월은 가을입니다.");
				
			}
			if(num == 12 || num <= 2) {
				System.out.println(num + "월은 겨울입니다.");
			
			}
			
			
		}
	}

}
