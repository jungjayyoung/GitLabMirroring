import java.io.*;
import java.util.*;

public class q8 {

	public static void main(String[] args) throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		String s = br.readLine();
		String tmp = "";
		
		int sum = 0;
		for(int i = 0; i < s.length(); i++) {
			if(s.charAt(i) >= 'A' && s.charAt(i) <= 'Z') {
				tmp = tmp + s.charAt(i);
			}else {
				sum += s.charAt(i) -'0';
			}
		}
		
		char[] sortedArray = tmp.toCharArray();
		Arrays.sort(sortedArray);
		tmp = new String(sortedArray);
		System.out.print(tmp + sum);
	}

}
