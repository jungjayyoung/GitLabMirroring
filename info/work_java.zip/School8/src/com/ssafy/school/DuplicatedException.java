package com.ssafy.school;

public class DuplicatedException extends Exception{
	
	
	public DuplicatedException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	public DuplicatedException() {
		this("Not Found Exception");
	}

	

}
