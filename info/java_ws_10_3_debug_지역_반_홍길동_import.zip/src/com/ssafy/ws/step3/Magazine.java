package com.ssafy.ws.step3;

public class Magazine extends Book{
	private int year;
	private int month;
	
	
	
	public Magazine() {
		super();
		// TODO Auto-generated constructor stub
	}
	//super 생성자 반드시 붙이기, 생성자는 리턴 타입이 없다!!
	public Magazine(String isbn, String title, String author, String publisher, int price, String desc, int quantity,int year, int month) {
		super(isbn, title, author, publisher, price, desc, quantity);
		setYear(year);
		setMonth(month);
		
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(super.toString()).append("\t|")
		.append(getYear()).append("\t|")
		.append(getMonth());
		return builder.toString();
	}	
	
	
	
	
	
}
