package com.ssafy.ws.step3;

import java.io.*;
import java.util.*;


public class CarSort{
	static class Car implements Comparable<Car>{
		String name;
		int year;
		
		public Car(String name, int year) {
			this.name = name;
			this.year = year;
		}
		
		@Override
		public String toString() {
			return name + year;
		}

		@Override
		public int compareTo(Car o) {
			return name.compareTo(o.name);
		}
		
		
	}
	
	
	public static void main(String[] args) {
		
		Car[] ca = {
				new Car("아반테",2015),
				new Car("그렌저",2007),
				new Car("소나타",2022),
		};
		int[] ia={22,11,33};
		System.out.println(Arrays.toString(ca));
		//Arrays.sort(ca);
		Arrays.sort(ca,Comparator.reverseOrder()); // 역순
		System.out.println(Arrays.toString(ca));
		System.out.println();
		
		List<Car> cl = new ArrayList<>();
		
		cl.add(new Car("아반테",2015));
		cl.add(new Car("그렌저",2007));
		cl.add(new Car("소나타",2022));
		System.out.println(cl);
		//Collections.sort(cl);
		Collections.sort(cl,Comparator.reverseOrder()); //역순
		
		System.out.println(cl);
		
		
		//연도오름차순
		class YearComparator implements Comparator<Car>{

			@Override
			public int compare(Car o1, Car o2) {
				
				return Integer.compare(o1.year, o2.year);
			}
			
		};
		// 연도 오름차순 사용법
		Comparator<Car> yc = new YearComparator();
		Collections.sort(cl,yc);
		System.out.println(cl);
		
		
//		Collections.sort(cl,new Comparator<Car>() {
//			
//			public int compare(Car o1, Car o2) {
//				return Integer.compare(o1.year, o2.year);
//			}
//		});
		
		Collections.sort(cl, (Car o1, Car o2)-> {
			return Integer.compare(o1.year, o2.year);		
	});
		
		System.out.println(cl);
		Collections.sort(cl,(o1,o2) -> o1.name.compareTo(o2.name));
		
		System.out.println(cl);
		System.out.println();
		
		
		List<Integer> il=new ArrayList<>();
		il.add(22);
		il.add(11);
		il.add(33);
		System.out.println(il);
		//Collections.sort(il);
		Collections.sort(il);
		System.out.println(il);
		System.out.println();
	}
}
