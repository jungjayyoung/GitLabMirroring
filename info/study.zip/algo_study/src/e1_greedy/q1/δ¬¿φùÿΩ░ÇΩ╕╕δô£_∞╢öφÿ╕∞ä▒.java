package 모험가길드;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class 모험가길드_추호성 {

	public static void main(String[] args) throws Exception {
		// read file
		BufferedReader bf = new BufferedReader(new FileReader("C:\\SSAFY\\algo_study\\1_그리디_기출\\src\\모험가길드"));

		// init
		int size = Integer.parseInt(bf.readLine());
		int[] arr = new int[size];

		// String data = bf.readLine();
		StringTokenizer st = new StringTokenizer(bf.readLine(), " ");
		for (int i = 0; i < size; i++)
			arr[i] = Integer.parseInt(st.nextToken());

		// algo
		Arrays.sort(arr);

		int result = 0;
		int idx = 0;
		int amt = 0;

		for (int i = 0; i < size; i++) {
			amt += 1;

			if (arr[i] == amt) {
				result += 1;
				amt = 0;
			}
		}
		System.out.println(result);

		bf.close();
	}

}
