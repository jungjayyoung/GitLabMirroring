package com.ssafy.live3.generic.box;

public class NormalBox {

	private Object some;

	public NormalBox() {}
	
	public NormalBox(Object some) {
		super();
		this.some = some;
	}
	
	public Object getSome() {
		return some;
	}

	public void setSome(Object some) {
		this.some = some;
	}
	
}
