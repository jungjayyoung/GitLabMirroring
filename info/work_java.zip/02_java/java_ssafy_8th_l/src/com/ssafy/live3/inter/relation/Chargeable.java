package com.ssafy.live3.inter.relation;

public interface Chargeable {
    void charge();
}
