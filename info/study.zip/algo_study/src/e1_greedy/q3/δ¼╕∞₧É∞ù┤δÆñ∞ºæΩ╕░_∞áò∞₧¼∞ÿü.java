import java.io.*;
import java.util.*;


public class q3 {

	public static void main(String[] args) throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		String s = br.readLine();
		
		int zero_cnt = 0;
		int one_cnt = 0;
		
		boolean is_one = false;
		boolean is_zero = false;
		
		for(int i=0;i<s.length();i++) {
			
			if(s.charAt(i) == '0') {
				
				if(!is_zero) {
					zero_cnt++;
				}
				is_zero = true;
				is_one = false;
				
			}else if(s.charAt(i) == '1') {
				if(!is_one) {
					one_cnt++;
				}
				is_one = true;
				is_zero = false;
			}
			
		}
		
		System.out.print(Math.min(zero_cnt, one_cnt));
		
		

	}

}
