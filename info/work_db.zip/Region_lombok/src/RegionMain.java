import java.util.ArrayList;
import java.util.List;

public class RegionMain {

	public static void main(String[] args) {
		List<RegionDto> data = new ArrayList<>();
		data.add(new RegionDto(1,"유럽"));
		data.add(new RegionDto(2,"아메리카"));
		data.add(new RegionDto(3,"아시아"));
		data.add(new RegionDto(4,"중동"));
		//System.out.println(data);
		
		for(RegionDto dto:data) System.out.println(dto);
		

	}

}
