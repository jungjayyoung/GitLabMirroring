package day5;

import java.io.Serializable;
import java.rmi.Remote;

class A{
	
	
	
}

class B{
	
	
}


// 자바에서 다중 상속을 받으려면 implements를 사용한다.
abstract class Pet extends A implements Serializable, Remote{
	
	private String name;
	
	public Pet(String name) {
		setName(name);
	}
	

	
	public Pet() {
		this("pet");
	}
	
	// abstract: 어차피 상속과 오버라이딩으로 사용되기 때문에 코딩 안한다.
	// abstract 메서드가 있으면 클래스 앞에 abstract를 붙여야 한다.
	public abstract void speak();

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}

class Cat extends Pet{
	@Override
	public void speak() {
		System.out.println("야옹");
	}
}

class Dog extends Pet{
	@Override
	public void speak() {
		System.out.println("멍멍");
	}
}

class Duck extends Pet{
	@Override
	public void speak() {
		System.out.println("꿱꿱");
	}
}

public class PetTest {

	public static void main(String[] args) {

		Pet p = new Dog();
		p.speak();
		
		//Pet p1 = new Pet();
		//p1.speak();
		
		Pet[] pa = new Pet[3];
		pa[0] = new Cat();
		pa[1] = new Dog();
		pa[2] = new Duck();
		
		for(Pet t:pa) t.speak();
		
	}

}
