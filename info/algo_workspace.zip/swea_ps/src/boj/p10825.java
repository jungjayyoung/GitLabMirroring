package boj;

import java.util.*;
import java.io.*;

public class p10825 {

	public static void main(String[] args) {
		BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st;
		
		
		
	}

}
