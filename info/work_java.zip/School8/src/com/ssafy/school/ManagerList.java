package com.ssafy.school;

import java.util.Arrays;
import java.util.List;
import java.util.Vector;

public class ManagerList implements IManager {

	
	private List<Person> pa;
	
	//2
	private static IManager instance = new ManagerList();
	
	//3
	public static IManager getInstance() {
		return instance;
	}
	
	private ManagerList(int size) {
		pa = new Vector<>(size);
	}
	
	public  ManagerList() {
		
	}
	
	@Override
	public void add(Person p) throws DuplicatedException{
		
		try {
			search(p.getName());
			throw new DuplicatedException(p.getName() + " 이미 등록되었습니다");
		} catch (NotFoundException e) {
			pa.add(p);
		}
	}
	
	@Override
	public Person[] search() {
		return pa.toArray(new Person[0]);
	}
	
	@Override
	public Person search(String name) throws NotFoundException {
		
		for(Person p : pa) { //pa.length를 하게 되면 NullPointerException 이 터진다.
			if(p.getName().equals(p.getName())) {
				return p;
			}
		}
		throw new NotFoundException(name + " 없습니다.");
	}
	
	@Override
	public void update(Person p) throws NotFoundException {
		Person t = search(p.getName());
		pa.set(pa.indexOf(t), p);
	}
	
	@Override
	public void delete(String name) throws NotFoundException{
		Person p = search(name);
		pa.remove(p);
	}
	
	@Override
	public void printAll() {
		for(Person p: pa) p.printAll();
	}
	
}
