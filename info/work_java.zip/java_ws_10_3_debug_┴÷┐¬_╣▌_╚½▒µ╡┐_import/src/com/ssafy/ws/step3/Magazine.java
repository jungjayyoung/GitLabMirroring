package com.ssafy.ws.step3;

public class Magazine{
	int year;
	int month;	
}
