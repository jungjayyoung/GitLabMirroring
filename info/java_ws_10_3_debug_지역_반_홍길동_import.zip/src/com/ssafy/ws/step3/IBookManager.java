package com.ssafy.ws.step3;

public interface IBookManager {

	
	// 예외처리 꼭 정의해서 집어넣기
	void add(Book book)throws DuplicatedException;
	void remove(String isbn) throws ISBNNotFoundException;
	Book[] getList();
	Book searchByIsbn(String isbn) throws ISBNNotFoundException;
	Book[] searchByTitle(String title);
	Book[] getBooks();
	Magazine[] getMagazines();
	int getTotalPrice();
	double getPriceAvg();
	void buy(String isbn, int quantity) throws ISBNNotFoundException;
	void sell(String isbn, int quantity) throws ISBNNotFoundException, QuantityException;
	void saveData();
	
	
}
