package codingbook.greedy;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Main_Q1_모험가길드_이하림 {

	public static void main(String[] args) throws IOException {
		BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
		int n = Integer.parseInt(bf.readLine());
		int[] arr = new int[n];
		StringTokenizer st = new StringTokenizer(bf.readLine(), " ");
		for(int i=0;i<n;i++) arr[i] = Integer.parseInt(st.nextToken());
		
		Arrays.sort(arr);
		int answer = 0;
		int cnt = arr[0];
		int fear = arr[0];
		for(int i=0; i<n; i++) {
			if(cnt == 0) { //그룹 완성
				answer++;
				fear = arr[i];
				cnt = arr[i];
			}
			if(arr[i] > fear) { //이전에 포함해야 하는 사람보다 늘어난 경우
				fear = arr[i];
				cnt++;
			}
			cnt--; //해당 인덱스 사람 그룹에 포함
			
		}
		if(cnt == 0) answer++; //마지막 확인
		
		System.out.println(answer);
	}

}
