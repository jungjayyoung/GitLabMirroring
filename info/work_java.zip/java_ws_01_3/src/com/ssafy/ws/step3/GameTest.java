package com.ssafy.ws.step3;

import java.util.Scanner;

/**
 * 가위,바위,보 게임을 하는 클래스
 */
public class GameTest {

	public static void main(String[] args) {
		//코드를 작성하세요.
		Scanner sc = new Scanner(System.in);
		System.out.println("1. 5판 3승");
		System.out.println("2. 3판 2승");
		System.out.println("3. 1판 1승");
		System.out.println();
		
		System.out.print("번호를 입력하세요. ");
		int num = sc.nextInt();
		int round = 0;
		
		if(num == 1) {
			round = 5;
		}else if(num == 2) {
			round = 3;
		}else if(num == 3) {
			round = 1;
		}
		
		int computer = 0;
		int player = 0;
		String [] comp = new String [] {"가위","바위","보"};
		
		int a = round;
		
		while(a-- > 0) {
			
			System.out.print("가위바위보 중 하나 입력 ");
			int pick = sc.nextInt();
			int comp_pick = (int)(Math.random() * 3) + 1;
			
			if(comp_pick == pick) {
				System.out.println("비겼습니다!!");
			}
			
			if(comp_pick == 1) {
				if(pick == 2) {
					System.out.println("이겼습니다!!");
					player++;
				}else if(pick == 3) {
					System.out.println("졌습니다!!");
					computer++;
				}
			}
			
			if(comp_pick == 2) {
				if(pick == 3) {
					System.out.println("이겼습니다!!");
					player++;
				}else if(pick == 1) {
					System.out.println("졌습니다!!");
					computer++;
				}
			}
			
			if(comp_pick == 3) {
				if(pick == 1) {
					System.out.println("이겼습니다!!");
					player++;
				}else if(pick == 2) {
					System.out.println("졌습니다!!");
					computer++;
				}
			}
			
			if(num == 1) {
				if(computer == 3 || player == 3) {
					break;
				}
			}
			if(num == 2) {
				if(computer == 2 || player == 2) {
					break;
				}
			}
			if(num == 3) {
				if(computer == 1 || player == 1) {
					break;
				}
			}
			
			
		}
		
		if(computer == player) {
			System.out.println("### 비겼습니다");
		}else if(computer > player) {
			System.out.println("### 컴퓨터 승!!!");
		}else if(computer < player) {
			System.out.println("### 플레이어 승!!!");
		}
		
		
	}
}
