package java_ws_11_3;

public class Test {

	public static void main(String[] args) {

		System.out.println(Integer.parseInt("123a"));
	}

}
