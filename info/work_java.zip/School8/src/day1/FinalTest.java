package day1;

public class FinalTest {

	// i,j,k,l 을 비교 설명하시오
	public static final int i = 11; //상수 class
	public static int j = 12; 		//변수 클래스
	public final int k = 13;        //상수 heap
	public int l = 14;				//변수 인스턴스
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(1/2);
		System.out.println(1./2);
		System.out.println(1/2.);
		System.out.println(1./2.);
	}

}
