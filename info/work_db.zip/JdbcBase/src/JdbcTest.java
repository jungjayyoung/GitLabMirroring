import java.sql.*;



public class JdbcTest {

	public static void main(String[] args) throws Exception{
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		String sql ="select * from regions";
		Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/ssafydb?serverTimezone=UTC", "ssafy", "ssafy");
		Statement st = con.createStatement();
		
		ResultSet rs = st.executeQuery(sql);
		
		while(rs.next()) {
			System.out.println(rs.getInt("region_id")+ " "+ rs.getString(2));
		}
		
		rs.close();
		st.close();
		con.close();
	}
}
