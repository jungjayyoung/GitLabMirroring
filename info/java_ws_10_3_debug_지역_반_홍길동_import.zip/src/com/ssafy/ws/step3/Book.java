package com.ssafy.ws.step3;

import java.io.Serializable;

public class Book implements Serializable, Comparable<Book>{ // Serializable을 붙여야 Serializable이 된다. 시험문제!
	private String isbn;		
	private String title;		
	private String author;		
	private String publisher;	
	private int price;			
	private String desc;		
	private int quantity;
	
	
	
	public Book() {
		
	}
	
	public Book(String isbn, String title, String author) {
		this(isbn,title,author,null,0,null,0);
	}
		
		
	
	public Book(String isbn, String title, String author, String publisher, int price, String desc, int quantity) {
		setIsbn(isbn);
		setTitle(title);
		setAuthor(author);
		setPublisher(publisher);
		setPrice(price);
		setDesc(desc);
		setQuantity(quantity);
		
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(getIsbn()).append("\t|")
		.append(getTitle()).append("\t|")
		.append(getAuthor()).append("\t|")
		.append(getPublisher()).append("\t|")
		.append(getPrice()).append("\t|")
		.append(getDesc()).append("\t|")
		.append(getQuantity());
		return builder.toString();
	}

	
	@Override
	public int compareTo(Book o) {
		// 타이틀 오름차순 정렬
		// 타이틀이 같으면 가격 순으로 정렬
		int r = title.compareTo(o.title);
		if(r==0) r = Integer.compare(price, o.price);
		return r;
	}			
	
	
	
	
	
	
	
}