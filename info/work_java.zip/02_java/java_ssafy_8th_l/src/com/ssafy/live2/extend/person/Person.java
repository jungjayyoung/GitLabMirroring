package com.ssafy.live2.extend.person;

public class Person {
	String name = "피터파커";
	public Person(String name) {
		this.name = name;
	}
	public void eat() {
		System.out.println("냠냠");
	}
	public void jump() {
		System.out.println("두다리로 폴작");
	}
	public String toString() {
		return "person:, name : " + this.name;
	}
}
