package com.ssafy.ws.step3;

import com.ssafy.ws.step3.Book;
import com.ssafy.ws.step3.BookManagerImpl;
import com.ssafy.ws.step3.IBookManager;
import com.ssafy.ws.step3.Magazine;

/**
 * BookManager 클래스를 이용하여 도서 객체 추가,삭제,조회하는 클래스
 */
public class BookTest {
	public static void main(String[] args) {
		IBookManager m = BookManagerImpl.getInstance();
		// BookManager 객체를 이용해  도서정보를 추가한다.
		m.add(new Book("21424", "Java Pro", "김하나", "jaen.kr", 15000, "Java 기본 문법",10));
		m.add(new Book("21425", "Java Pro2", "김하나", "jaen.kr", 25000, "Java 응용",20));
		m.add(new Book("35355", "분석설계", "소나무", "jaen.kr", 30000, "SW 모델링",30));
		m.add(new Magazine("12", "월간알고리즘", "홍길동", "jaen.kr", 10000, "SW 모델링",40,2021,1));
		

	
		
		// BookManager 객체를 이용해  도서 전체 리스트를 조회한다.
		System.out.println("**********************도서 전체 목록**********************");
		for (Book book : m.getList()) {
			System.out.println(book);
		}	
		
		// BookManager 객체를 이용해  일반 도서 리스트만 조회한다.
		System.out.println("**********************일반 도서 목록**********************");
		for (Book book : m.getBooks()) {
			System.out.println(book);
		}
		
		// BookManager 객체를 이용해  잡지 리스트만 조회한다.
		System.out.println("**********************잡지목록**********************");
		for (Book b : m.getMagazines()) {
			System.out.println(b);
		}
				
				
		//도서 제목 포함 검색
		System.out.println("**********************도서 제목 포함**********************");
		for (Book book : m.searchByTitle("Java ")) {
			System.out.println(book);
		}
		
	
		//도서 가격 총합
		System.out.println("도서 가격 총합: " + m.getTotalPrice());
		System.out.println("도서 가격 평균: " +m.getPriceAvg());
		
		
		
		
		
		
		try {
	        // BookManager 객체를 이용해  도서를 수량만큼 판매한다.
	        System.out.println("**********************도서판매:21424,11개**********************");
	        m.sell("21424",11);
	    } catch (ISBNNotFoundException e) {
	        System.out.println(e.getMessage());
	    } catch (QuantityException e) {
	        System.out.println(e.getMessage());
	    }
	    
	    try {
	        // BookManager 객체를 이용해  도서를 수량만큼 구매한다.
	        System.out.println("**********************도서구매:21424,10개**********************");
	        m.buy("21424",10);
	    } catch (ISBNNotFoundException e) {
	        System.out.println(e.getMessage());
	    }        
	    System.out.println(m.searchByIsbn("21424"));
	    
	    try {
	        // BookManager 객체를 이용해  도서를 수량만큼 판매한다.
	        System.out.println("**********************도서판매:21424,11개**********************");
	        m.sell("21424",11);
	    } catch (ISBNNotFoundException e) {
	        System.out.println(e.getMessage());
	    } catch (QuantityException e) {
	        System.out.println(e.getMessage());
	    }
	    System.out.println(m.searchByIsbn("21424"));
	}
}
