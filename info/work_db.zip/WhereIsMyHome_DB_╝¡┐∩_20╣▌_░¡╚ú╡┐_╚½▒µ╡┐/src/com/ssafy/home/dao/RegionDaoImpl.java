package com.ssafy.home.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.home.dto.RegionDto;
import com.ssafy.home.util.DBUtil;

public class RegionDaoImpl implements RegionDao {
	private static RegionDao instance = new RegionDaoImpl();
	private RegionDaoImpl() {}
	
	public static RegionDao getInstance() {
		
		return instance;
	}

	private DBUtil util = DBUtil.getUtil();
	
	@Override
	public void insert(RegionDto dto) throws SQLException {

		String sql ="insert into regions values(?,?)";

		try(Connection con = util.getConnection();
			PreparedStatement ps = con.prepareStatement(sql);) {
			ps.setInt(1,dto.getId());
			ps.setString(2,dto.getName());
			ps.executeUpdate();
		}
	}

	@Override
	public List<RegionDto> selectAll() throws SQLException {
		List<RegionDto> list = new ArrayList<>();
		String sql ="select * from regions";

		try(Connection con = util.getConnection();
			PreparedStatement ps = con.prepareStatement(sql);) {
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				list.add(new RegionDto(rs.getInt("region_id"),rs.getString(2)));
			}
			if(rs != null) rs.close();
		}
		return list;
	}

	@Override
	public RegionDto select(int id) throws SQLException {
		
		RegionDto dto = null;
		String sql ="select * from regions where region_id=?";

		try(Connection con = util.getConnection();
			PreparedStatement ps = con.prepareStatement(sql);) {
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				dto = new RegionDto(rs.getInt("region_id"),rs.getString(2));
			}
			if(rs != null) rs.close();
		}
		return dto;
	}

	@Override
	public void update(RegionDto dto) throws SQLException {
		String sql ="update regions set region_name=? where region_id=?";

		try(Connection con = util.getConnection();
			PreparedStatement ps = con.prepareStatement(sql);) {
			ps.setString(2,dto.getName());
			ps.setInt(1,dto.getId());
			ps.executeUpdate();
		}

	}

	@Override
	public void delete(int id) throws SQLException {
		String sql ="delete from regions where region_id=?";
		try(Connection con = util.getConnection();
			PreparedStatement ps = con.prepareStatement(sql);) {
			ps.setInt(1,id);
			ps.executeUpdate();
		}

	}

}
