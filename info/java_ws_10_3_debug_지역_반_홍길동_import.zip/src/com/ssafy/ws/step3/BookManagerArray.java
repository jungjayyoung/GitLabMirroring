package com.ssafy.ws.step3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Arrays;

public class BookManagerArray implements IBookManager {
	
	private static final int MAX_SIZE = 100;
	private Book[] books = new Book[MAX_SIZE]; // NullPointerException 이 나오지 않게 객체를 생성해야 한다!!
	private int size;
	
	
	
	//2.
	private static IBookManager instance = new BookManagerArray();
	
	
	
	//1.
	private BookManagerArray() {
		loadData();
	}
	
	//3.
	public static IBookManager getInstance() {
		return instance;
	}

	@Override
	public void add(Book book){

		try {
			searchByIsbn(book.getIsbn());
		} catch (ISBNNotFoundException e) {
			books[size++] = book;
		}
		
	}

	@Override
	public void remove(String isbn) throws ISBNNotFoundException {

		for(int i=0; i<size; i++) {
			if(books[i].getIsbn().equals(isbn)) { // == 이 아니라 equals로 비교 해야한다. equals가 오버라이딩 되있어야 한다.
				books[i] = books[--size];
				return;
			}
		}
		throw new ISBNNotFoundException(isbn);
	}

	@Override
	public Book[] getList() {

		return Arrays.copyOf(books, size); // 그냥 books 하면 안된다. Arrays.copyof 사용해야 한다.
	}

	@Override
	public Book searchByIsbn(String isbn) throws ISBNNotFoundException {
		for(int i = 0; i<size;i++) {
			if(books[i].getIsbn().equals(isbn)) return books[i];
		}
		throw new ISBNNotFoundException(isbn);
	}

	@Override
	public Book[] searchByTitle(String title) {
		
		Book[] tmp = new Book [size]; // tmp 배열을 만들어 준다.
		int cnt =0;
		
		for(int i = 0; i <size; i++) {
			if(books[i].getTitle().contains(title)) { //contains로 찾는다
				tmp[cnt++] =books[i];
			}
		}
		return Arrays.copyOf(tmp, cnt); // 여기도 Arrays.copyof 사용
	}

	@Override
	public Book[] getBooks() {
		Book[] tmp = new Book [size]; // tmp 배열을 만들어 준다.
		int cnt =0;
		
		for(int i = 0; i <size; i++) {
			if(!(books[i] instanceof Magazine)) { //instance of Magazine 이 아닌걸 집어넣어야 되니까 !를 붙인다.
				tmp[cnt++] =(Magazine)books[i]; // magazine으로 형변환해서 집어넣기
			}
		}
		return Arrays.copyOf(tmp, cnt); // 여기도 Arrays.copyof 사용
	}

	@Override
	public Magazine[] getMagazines() {
		Magazine[] tmp = new Magazine [size]; // tmp 배열을 만들어 준다.
		int cnt =0;
		
		for(int i = 0; i <size; i++) {
			if(books[i] instanceof Magazine) { //instance of Magazine 이냐?
				tmp[cnt++] =(Magazine)books[i]; // magazine으로 형변환해서 집어넣기
			}
		}
		return Arrays.copyOf(tmp, cnt); // 여기도 Arrays.copyof 사용
	}

	@Override
	public int getTotalPrice() {
		int total = 0;
		
		for(int i = 0; i<size; i++) {
			total += books[i].getPrice();
		}
		
		return total;
	}

	@Override
	public double getPriceAvg() {
		
		return (double)getTotalPrice() / size; // 반드시 double로 형변환하기
	}

	@Override
	public void buy(String isbn, int quantity) throws ISBNNotFoundException {
		Book b = searchByIsbn(isbn);
		b.setQuantity(b.getQuantity() + quantity);
	}

	@Override
	public void sell(String isbn, int quantity) throws ISBNNotFoundException, QuantityException {
		Book b = searchByIsbn(isbn);
		int r = b.getQuantity() - quantity;
		if(r <0) throw new QuantityException();
		b.setQuantity(r);
	
		
	}

	@Override
	public void saveData() {
		
		try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("book.dat"));) {
			oos.writeObject(books);
			oos.writeObject(size); //배열이므로 size 도 관리해줘야 한다.
			oos.flush();
			System.out.println("[SYSTEM] 파일 쓰기 성공");
		} catch (Exception e) {
			System.out.println("[SYSTEM] 파일 쓰기 성공");
			e.printStackTrace();
		}
	}
	
	private void loadData() {
		
		File f =new File("book.dat");
		if(f.exists()) {
			try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));){
				books = (Book[])ois.readObject();
				size = (int)ois.readObject();				//NULLPointerException 발생 !!!! 로컬 변수가 아닌 기존 변수를 사용한다.
				// 대입을 해줘야 한다.
				System.out.println("[SYSTEM] 파일 읽기 성공");
			} catch (Exception e) {
				System.out.println("[SYSTEM] 파일 읽기 실패");
				e.printStackTrace();
			}
			
		}
		
	}

}
