package com.ssafy.live2.poly;

import com.ssafy.live2.extend.person.Person;
import com.ssafy.live2.extend.person.SpiderMan;

public class PolySpiderTest {

	public static void main(String[] args) {
		SpiderMan sman = new SpiderMan("피터파커",  false);
		//다형성
		SpiderMan sman2 = sman;
		Person person = sman;
		Object obj = person;
		Object obj2 = sman;
		
		// 명시적 형변환
		SpiderMan reSpider = (SpiderMan)obj; //부모가 자식이될 때는 안되는게 있을 수 있으니깐
		
		// 뭐든지 담을 수 있는 만능 주머니
		Object[] objs = new Object[4];
		objs[0] = sman;
		objs[1] = "Hello";
		objs[2] = objs;
		objs[3] = 1; //원래 개념이라면 안되야함, autoboxing 때문에 들어감
		
		SpiderMan fromObjArray = (SpiderMan) objs[0];
		fromObjArray.fireWeb();
		
		//형변환 시 타입 반드시 확인하고 하자
		if(objs[1] instanceof SpiderMan) {
			SpiderMan fromobjArray2 = (SpiderMan) objs[1];
			fromobjArray2.fireWeb();
		}
		
		for(Object o:objs) {
			System.out.println(o.getClass().getName());
		}
		
		System.out.println(sman2);
		System.out.println(person);
	}

}
