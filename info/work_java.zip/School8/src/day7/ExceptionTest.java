package day7;

import java.io.FileInputStream;
import java.io.IOException;

class MyException extends Exception{
	
	

	public MyException(String msg) {
		super(msg);
	}
	public MyException() {
		this("MyException");
	}
}
public class ExceptionTest {

	public static void main(String[] args) throws IOException{

		System.out.println("start");
		
		new FileInputStream("input.txt");
		
		try {
			String s = null;
			//System.out.println(s.length()); //NullPointerException -> 시험
			//예외가 발생하면 바로 catch 구문으로 가기 때문에 출력이 안된다.
			System.out.println("여기는 출력하고 싶다.");
			
			//IOException, 컴파일 자체가 안된다., checked Exception
			// 컴파일 에러가 발생
			//반드시 try catch를 해야한다.
			//System.in.read(); 
			//IOException ioe = new IOException("I/O 예외 발생...");
			//throw ioe;
			//throw new IOException("I/O 예외 발생...");
			
			//throw new MyException("예외가 나타났다");
			throw new NullPointerException("널 포인터 예외일까요");
			//return; //finally는 수행한다.
		} catch (NullPointerException e) {
			System.out.println("NullPointerException: " + e.getMessage());
			//e.printStackTrace();
		}catch (RuntimeException e) {
			System.out.println("RuntimeException: " + e.getMessage());
			//e.printStackTrace();
		}catch (Exception e) {
			System.out.println("Exception: " + e.getMessage());
			//e.printStackTrace();
		}catch (Throwable e) {
			System.out.println("Throwable: " + e.getMessage());
			//e.printStackTrace();
		} finally {
			System.out.println("finally");
		}
		
		System.out.println("end");
		
		
	}

}
