package com.ssafy.school;

import java.util.Arrays;
import java.util.List;
import java.util.Vector;

public class ManagerList implements IManager {

	
	private List<Person> pa;
	
	//2
	private static IManager instance = new ManagerList();
	
	//3
	public static IManager getInstance() {
		return instance;
	}
	
	private ManagerList(int size) {
		pa = new Vector<>(size);
	}
	
	public  ManagerList() {
		
	}
	@Override
	public void add(Person p) {
		pa.add(p);
	}
	
	@Override
	public Person[] search() {
		return pa.toArray(new Person[0]);
	}
	
	@Override
	public Person search(String name) {
		
		for(Person p : pa) { //pa.length를 하게 되면 NullPointerException 이 터진다.
			if(p.getName().equals(p.getName())) {
				return p;
			}
		}
		return null;
	}
	
	@Override
	public void update(Person p) {
		Person t = search(p.getName());
		if( t!= null) pa.set(pa.indexOf(t), p);
	}
	
	@Override
	public void delete(String name) {
		Person p = search(name);
		if( p!= null) pa.remove(p);
	}
	
	@Override
	public void printAll() {
		for(Person p: pa) p.printAll();
	}
	
}
