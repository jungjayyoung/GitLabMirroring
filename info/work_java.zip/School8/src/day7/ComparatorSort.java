package day7;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

//Comparator 는 커스텀 정렬 함수
class TitleComparator implements Comparator<Book>{

	@Override
	public int compare(Book o1, Book o2) {
		//제목을 기준으로 정렬할 때
		// - 가 붙으면 역순
		return o1.title.compareTo(o2.title);
		
	}
	
}

class PriceComparator implements Comparator<Book>{

	@Override
	public int compare(Book o1, Book o2) {
		//제목을 기준으로 정렬할 때
		// - 가 붙으면 역순
		return Integer.compare(o1.price, o2.price);
		
	}
	
}


class TitlePriceComparator implements Comparator<Book>{

	@Override
	public int compare(Book o1, Book o2) {
		
		if(o1.title.equals(o2.title)) {
			return Integer.compare(o1.price, o2.price);
		}else {
			return o1.title.compareTo(o2.title);
		}
		
		
	}
	
}
public class ComparatorSort {

	public static void main(String[] args) {

		
		Comparator<Book> tc = new TitleComparator();
		Comparator<Book> pc = new PriceComparator();
		Comparator<Book> tpc = new PriceComparator();
		
		
		Book[] ba = {
				new Book("123","자바",2000),
				new Book("987","알고",1000),
				new Book("456","가곡",3000),
				new Book("456","가곡",4000),
				new Book("456","가곡",1000)
				
		};
		System.out.println(Arrays.toString(ba));
		Arrays.sort(ba,tpc);// ClassCastException: java.lang.Comparable
		System.out.println(Arrays.toString(ba));
		System.out.println();
		
		
		// 리스트는 어떻게 정렬할까?
		// Collections.sort 사용
		List<Book> bl = new ArrayList<>();
		bl.add(new Book("123","자바",2000));
		bl.add(new Book("987","알고",1000));
		bl.add(new Book("456","가곡",3000));
		System.out.println(bl);
		
		Collections.sort(bl,Comparator.reverseOrder());
		System.out.println(bl);
		
	}

}
