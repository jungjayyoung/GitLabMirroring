package com.ssafy.school;

public class NotFoundException extends Exception{

	
	public NotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	public NotFoundException() {
		this("Not Found Exception");
	}

	

}
