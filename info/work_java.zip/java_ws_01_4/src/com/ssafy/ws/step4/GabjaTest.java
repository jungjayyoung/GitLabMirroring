package com.ssafy.ws.step4;

/**
 * 60 갑자를 서양력으로 변환하는 프로그램
 */
import java.util.*;

public class GabjaTest {

    public static void main(String[] args) {
    	
    	Scanner sc = new Scanner(System.in);
    	
    	System.out.println("60갑자를 입력하세요: ");
    	String s = sc.next();
    	int gan = 1;
    	int ez = 1;
    	int gann = 0;
    	int ezz = 0;
    	
    	if(s.charAt(0) == '갑') {
    		gann = 1;
    	}else if(s.charAt(0) == '을') {
    		gann = 2;
    	}else if(s.charAt(0) == '병') {
    		gann = 3;
    	}else if(s.charAt(0) == '정') {
    		gann = 4;
    	}else if(s.charAt(0) == '무') {
    		gann = 5;
    	}else if(s.charAt(0) == '기') {
    		gann = 6;
    	}else if(s.charAt(0) == '경') {
    		gann = 7;
    	}else if(s.charAt(0) == '신') {
    		gann = 8;
    	}else if(s.charAt(0) == '임') {
    		gann = 9;
    	}else if(s.charAt(0) == '계') {
    		gann = 10;
    	}
    	
    	if(s.charAt(1) == '자') {
    		ezz = 1;
    	}else if(s.charAt(1) == '축') {
    		ezz = 2;
    	}else if(s.charAt(1) == '인') {
    		ezz = 3;
    	}else if(s.charAt(1) == '묘') {
    		ezz = 4;
    	}else if(s.charAt(1) == '진') {
    		ezz = 5;
    	}else if(s.charAt(1) == '사') {
    		ezz = 6;
    	}else if(s.charAt(1) == '오') {
    		ezz = 7;
    	}else if(s.charAt(1) == '미') {
    		ezz = 8;
    	}else if(s.charAt(1) == '신') {
    		ezz = 9;
    	}else if(s.charAt(1) == '유') {
    		ezz = 10;
    	}else if(s.charAt(1) == '술') {
    		ezz = 11;
    	}else if(s.charAt(1) == '해') {
    		ezz = 12;
    	}
    	
    	for(int i= 1444; i<= 2100;i++) {
    		
    		if(i >= 1800) {
    			if(gan == gann && ez == ezz) {
        			System.out.print(i + " ");
        		}
    		}
    		
    		
    		gan++;
    		ez++;
    		if(gan >= 11) {
    			gan = 1;
    		}
    		if(ez >= 13) {
    			ez = 1;
    		}
    	}
    	
    }
}
