package day8;

import java.io.*;
import java.util.ArrayList;
import java.util.List;


class Phone implements Serializable{
	
	String name;
	String num;
	int price;
	public Phone(String name, String num, int price) {
		super();
		this.name = name;
		this.num = num;
		this.price = price;
	}
	
	
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Phone [name=").append(name).append(", num=").append(num).append(", price=").append(price)
				.append("]");
		return builder.toString();
	}
	
	
	
}


public class SerializeTest {

	public static void main(String[] args) {

		Phone p = new Phone("홍길동", "010-0010-0010", 2000);
		
		List<Phone> pl = new ArrayList<>();
		pl.add(new Phone("강호동","010-0020-0020",2000));
		pl.add(new Phone("사오정","010-0020-0021",1000));
		pl.add(new Phone("손오공","010-0020-0022",3000));
		
		
		
		try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("phone.ser"));){
			//oos.writeObject(p); // java.io.NotSerializableException: java.io.Serializable
			oos.writeObject(pl);
			oos.flush();
			
			System.out.println("write ok");
		}catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}

}
