package boj;

import java.io.*;
import java.util.*;


public class p2839 {

	public static void main(String[] args) throws IOException{

		
	}

}
