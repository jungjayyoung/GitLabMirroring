import java.sql.*;



public class JdbcTest7_insert {

	public static void main(String[] args) {
	    try {
	        Class.forName("com.mysql.cj.jdbc.Driver");
	    } catch (ClassNotFoundException e) {
	        // TODO Auto-generated catch block
	        e.printStackTrace();
	    }    // mysql jdbc driver를 로딩 (cj : common java)

	    String sql = "insert into regions values(?,?)";
	    try(Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/ssafydb?serverTimezone=UTC","ssafy","ssafy");
	            PreparedStatement st = con.prepareStatement(sql) {

	    st.setInt(1,5);
	    st.setString(2,"new Regions");
	    
	    int rs = st.executeUpdate();
	    
	    if(rs > 0) {    // 인서트 수가 0 이상
	        System.out.println("성공");
	    }
	    else {
	        System.out.println("실패");
	    }

	} catch (SQLException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
	    
	/*
	 * Exception in thread "main" java.lang.ClassNotFoundException: com.mysql.cj.jdbc.Driver
	 * classpath 걸어야한다. 프로젝트 우클릭 > Properties > Java Build Path > Add ExternalJars > mysql connector jar 추가해준다.
	 * */
}
