package p1979;

import java.util.Scanner;

public class p1979 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int tc;
		tc = sc.nextInt();
		
		for(int i = 1; i<= tc; i++) {
			int n = sc.nextInt();
			int k = sc.nextInt();
			
			int [][] arr = new int [n][n];
			
			
			//1. 입력
			for(int y = 0; y < n; y++) {
				for(int x = 0; x < n; x++) {
					arr[y][x] = sc.nextInt();
				}
			}
			int ans = 0;
			//2. 가로
			for(int y = 0; y < n; y++) {
				boolean zero_check = false;
				boolean one_check = false;
				int cnt = 0;
				
				for(int x = 0; x < n; x++) {
					
					if(arr[y][x] == 0) {
						
						if(one_check && cnt == k) {
							ans++;
						}
						zero_check = true;
						one_check = false;
					}else {
						
						if(!one_check) {
							cnt = 1;
						}else {
							cnt++;
						}
						zero_check = false;
						one_check = true;
					}
					
				}
				if(cnt == k) {
					ans++;
				}
				
			}
			
			
		
			//3. 세로
			for(int y = 0; y < n; y++) {
				boolean zero_check = false;
				boolean one_check = false;
				int cnt = 0;
				
				for(int x = 0; x < n; x++) {
					
					if(arr[x][y] == 0) {
						
						if(one_check && cnt == k) {
							ans++;
							cnt = 0;
						}
						zero_check = true;
						one_check = false;
					}else {
						
						if(!one_check) {
							cnt = 1;
						}else {
							cnt++;
						}
						zero_check = false;
						one_check = true;
					}
					
				}
				if(cnt == k) {
					ans++;
				}
				
			}
			
			
			System.out.println("#" + tc + " " + ans);
			
		}

	}

}
