function hello(message) {
	alert('Hello ' + message);
}

hello('JavaScript !!!');

