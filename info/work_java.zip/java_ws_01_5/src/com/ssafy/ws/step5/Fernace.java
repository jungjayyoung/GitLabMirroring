package com.ssafy.ws.step5;
import java.util.Scanner;

public class Fernace {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		int b = sc.nextInt();
		
		int n = sc.nextInt();
		
		int [] btn = new int[n];
		
		for(int i=0;i<n;i++) {
			btn[i] = sc.nextInt();
		}

		int ans = 601;
		
		// 1. 현재 온도에서 감소 또는 증가
		if(a < b) {
			ans = Math.min(ans, b-a);
		}else if(a > b) {
			ans = Math.min(ans, a-b);
		}
		
		for(int i = 0; i < n;i++) {
			
			// 2. 버튼을 누를 경우
			if(btn[i] > b) {
				ans = Math.min(ans, btn[i] - b + 1);
			}else if(btn[i] < b) {
				ans = Math.min(ans, b - btn[i] + 1);
			}else if(btn[i] == b) {
				ans = 1;
				break;
			}
			
		}
		
		if(ans > 600) {
			System.out.println(-1);
		}else {
			System.out.println(ans);
		}
		
		
	}

}
