package com.ssafy.home.dao;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.home.dto.RegionDto;

public interface RegionDao {
	void insert(RegionDto dto) throws SQLException;
	List<RegionDto> selectAll() throws SQLException;
	RegionDto select(int id) throws SQLException;
	void update(RegionDto dto) throws SQLException;
	void delete(int id) throws SQLException;
	
}
