import java.sql.*;



public class JdbcTest6_auto {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		String sql ="select * from regions where region_id=?";

		try(Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/ssafydb?serverTimezone=UTC", "ssafy", "ssafy");
				PreparedStatement ps = con.prepareStatement(sql);) {
			
			ps.setInt(1, 3);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				System.out.println(rs.getInt("region_id")+ " "+ rs.getString(2));
			}
			if(rs != null) rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
	}
}
