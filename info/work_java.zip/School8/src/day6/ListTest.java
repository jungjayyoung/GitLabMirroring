package day6;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class ListTest {

	public static void main(String[] args) {

		List<String> list = new LinkedList(); // 데이터의 중간 추가, 삭제가 빠름
		
		list.add("홍길동");
		System.out.println(list.indexOf("홍길동"));
		
	    //System.out.println(list);
		list.add("손오공");
		//System.out.println(list);
		System.out.println(list.indexOf("손오공"));
		list.add(0,"강호동");
		//System.out.println(list);
		System.out.println(list.indexOf("홍길동"));
		
		System.out.println(list.indexOf("손오공"));
		
		//for(int i = 0; i<list.size(); i++) System.out.println(list.get(i)); // 알고리즘에서 쓰임, 인덱스 요소를 알아야 할 때
		for(String s : list) System.out.println(s); // 자바에서 쓰임
		//System.out.println(list);
		
		/*
		Iterator it = list.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		*/
	}

}
