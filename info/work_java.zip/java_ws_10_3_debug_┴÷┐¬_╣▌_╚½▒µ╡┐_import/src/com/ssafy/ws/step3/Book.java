package com.ssafy.ws.step3;

public class Book{
	String isbn;		
	String title;		
	String author;		
	String publisher;	
	int price;			
	String desc;		
	int quantity;			
}