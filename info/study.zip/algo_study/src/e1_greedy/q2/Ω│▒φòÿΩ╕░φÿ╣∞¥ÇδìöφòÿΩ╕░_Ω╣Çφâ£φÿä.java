package e1_greedy.q2;

import java.io.*;
import java.util.*;

public class 곱하기혹은더하기_김태현 {
	public static void main(String[] args) throws Exception {
//		System.setIn(new FileInputStream("res/input_ect_11_2.txt"));
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		String str = new String(in.readLine());
		
		int result = str.charAt(0) - '0';
		int next = 0;
		for(int i=1;i<str.length();i++) {
			next = str.charAt(i) - '0';
			if(next == 0 || next == 1 || result == 0 || result == 1) {
				result += next;
			}else {
				result *= next;
			}
		}
		System.out.println(result);
		in.close();
	}
}

/*
02894

576
*/