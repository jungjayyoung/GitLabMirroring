package com.ssafy.ws.step3;

/**
 * B구획의 빌딩 최고 높이 구하기
 */ 
import java.util.*;
public class BuildingTest {
	static int [] dx = {-1,0,1,0,-1,1,-1,1};
	static int [] dy = {0,1,0,-1,-1,1,1,-1};

	public static void main(String[] args) throws Exception{
		
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();
		
		
		for(int tc = 1; tc <= T; tc++) {
			
			int N = sc.nextInt();
			
			char [][] board = new char[N][N];
			
			for(int y = 0; y<N;y++) {
				
				for(int x = 0; x <N;x++) {
					board[y][x] = sc.next().charAt(0);
				}
			}
			
			int max_height = 1;
			
			for(int y = 0; y < N; y++) {
				
				for(int x = 0; x <N; x++) {
					
					if(board[y][x] == 'B') {
						boolean check =false;
						
						for(int i = 0; i<8;i++) {
							
							if(y + dy[i]< 0 || y + dy[i] >= N || x + dx[i] < 0 || x + dx[i] >= N) {
								continue;
							}
							
							if(board[y + dy[i]][x + dx[i]] == 'G') {
								max_height = Math.max(max_height, 2);
								check = true;
							}
							
						}
						if(!check) {
							int cnt = 1;
							
							for(int k = 1; k < N; k++) {
								
								for(int i = 0; i < 4; i++) {
									
									if(y + dy[i] * k < 0 || y + dy[i] * k >= N || x + dx[i] * k < 0 || x + dx[i] * k >= N) {
										continue;
									}
									if(board[y + dy[i] * k][x + dx[i] * k] == 'B') {
										cnt++;
									}
									
								}
								
							}
							
							max_height = Math.max(max_height, cnt);
							
						}
						
						
					}
				}
			}
			
			System.out.println("#"+ tc + " " + max_height);
		}
		
		sc.close();
	}
}