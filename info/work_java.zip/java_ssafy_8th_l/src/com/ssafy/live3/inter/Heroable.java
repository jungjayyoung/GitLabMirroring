package com.ssafy.live3.inter;

public interface Heroable extends Fightable, Transformable{
	
	void upgrade();
	
}
