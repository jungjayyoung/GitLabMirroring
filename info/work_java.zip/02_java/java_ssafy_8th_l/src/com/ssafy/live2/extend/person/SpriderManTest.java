package com.ssafy.live2.extend.person;

public class SpriderManTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpiderMan sman = new SpiderMan("윤득렬", true);
		sman.eat();
		sman.jump();
		sman.fireWeb();
		sman.isSpider = true;
		sman.eat();
		sman.jump();
		sman.fireWeb();
		sman.love();
		System.out.println(sman.toString());
	}

}