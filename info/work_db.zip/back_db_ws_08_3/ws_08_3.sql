
use world;
select * from city;
select * from country;
select * from countrylanguage;

#1 도시명 kabul이 속한 국가의 이름은?
select c.code, c.name 
from country c join city 
on city.CountryCode = c.Code 
where city.name = 'kabul';

#2. 국가의 공식 언어 사용율이 100%인 국가의 정보를 출력하시오. 국가 이름으로 오름차순 정렬한다.
select c.name, cl.language, cl.percentage
from country c join countrylanguage cl 
on cl.countrycode = c.Code
where cl.percentage = 100.0 and cl.isofficial = true
order by c.name;

#3 도시명 amsterdam에서 사용되는 주요 언어와 amsterdam이 속한 국가는?
select c2.name, c1.language, c.name
from country c join countrylanguage c1 
on c1.countrycode = c.Code
join city c2
on c2.countrycode = c.code
where c2.name = 'amsterdam' and c1.percentage >= 50;



#15 국가별로 가장 인구가 많은 도시의 정보를 출력하시오. 국가 코드로 정렬한다.

select *
from city join country
on city.countrycode = country.code
where ;

select *
from city;

select *
from city
where max(population) group by city.countrycode;

