package e1_greedy.q1;

import java.io.*;
import java.util.*;

public class 모험가길드_김태현 {
	public static void main(String[] args) throws Exception {
//		System.setIn(new FileInputStream("res/input_ect_11_1.txt"));
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		
		int N = Integer.parseInt(in.readLine());
		StringTokenizer st = new StringTokenizer(in.readLine());
		int[] adventurer = new int[N+1];
		for(int i=0;i<N;i++) {
			adventurer[Integer.parseInt(st.nextToken())]++;
		}
		
		int enough = 0;
		for(int i=1;i<N+1;i++) {
			if(adventurer[i] >= i) {
				enough++;
			}
		}
		System.out.println(enough);
		in.close();
	}
}
/*
5
2 3 1 2 2
7
1 2 3 2 1 3 3


2
3
*/