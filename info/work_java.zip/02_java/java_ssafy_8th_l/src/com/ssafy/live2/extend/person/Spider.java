package com.ssafy.live2.extend.person;

public class Spider {
	public void jump() {
		System.out.println("어마어마하게 높은 점프 가능");
	}
	
	public void firWeb() {
		System.out.println("거미줄 쉭쉭~~");
	}

}
