package com.ssafy.live3.inter;

public interface Transformable {
	void changeShape(boolean isHeroMode);
}
