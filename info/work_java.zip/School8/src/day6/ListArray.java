package day6;

import java.util.*;

public class ListArray {

	public static void main(String[] args) {

		int[] ia = new int[3];
		ia[0] = 10;
		System.out.println(Arrays.toString(ia));
		System.out.println();
		
		//배열을 만들 때 generics를 붙이면 안된다.
		List<Integer>[] li = new List[3];
		for(int i = 0; i<3;i++) li[i] = new ArrayList<>();
		li[0].add(123);
		System.out.println();
		System.out.println(li[0]);
	}

}
