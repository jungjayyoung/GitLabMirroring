package java_ws_11_3;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class WeatherDAODOM {
	private List<Weather> list;

	private static WeatherDAODOM instance = new WeatherDAODOM();
	private WeatherDAODOM() {
	}
	
	public static WeatherDAODOM getInstance() {
		return instance;
	}

	public void connectXML() {
		String url = "http://www.kma.go.kr/wid/queryDFSRSS.jsp?zone=1168064000";//서울시 감남구 역삼1동
		try {
			
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document dom = builder.parse(url);
			Element root = dom.getDocumentElement();
			NodeList nlist = root.getElementsByTagName("data");
			System.out.println(nlist.getLength());
			parse(nlist);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void parse(NodeList nlist) {
		list = new ArrayList<>();
		for (int i = 0; i < nlist.getLength(); i++) {
			Node node = nlist.item(i);
			NodeList childs = node.getChildNodes();
			int hour = 0;
			double temp = 0;
			String wfKor = null;
			int reh = 0;
			for (int j = 0; j < childs.getLength(); j++) {
				Node child = childs.item(j);

				//작성하세요...
				String nodeName = child.getNodeName();
				String textContent = child.getTextContent();
				
				if(nodeName.equals("hour")) {
					hour = Integer.valueOf(child.getTextContent());
				}else if(nodeName.equals("temp")) {
					temp = Double.valueOf(child.getTextContent());
				}else if(nodeName.equals("wfKor")) {
					wfKor = child.getTextContent();
				}else if(nodeName.equals("reh")) {
					reh = Integer.valueOf(child.getTextContent());
				}

			}
			list.add(new Weather(hour, temp, wfKor, reh));
		}
		System.out.println(list);
	}
	public List<Weather> getWeatherList(){
		return list;
	}
}
