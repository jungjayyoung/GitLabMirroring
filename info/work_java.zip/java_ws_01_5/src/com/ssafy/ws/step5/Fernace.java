package com.ssafy.ws.step5;
import java.util.Scanner;

public class Fernace {

	public static void main(String[] args) {

		System.out.println("");
		
	}

}
