package src.com.ssafy.ws.step3;

import java.util.*;

/**
 * 도서리스트를 배열로 유지하며 관리하는 클래스
 */
public class BookManagerArray implements IBookManager {

	private static int MAX_SIZE=100;
	private List<Book> bookList = new ArrayList<>();
	
	
	private BookManagerArray() {}
	private static IBookManager instance = new BookManagerArray();
	
	public static IBookManager getInstance() {
		return instance;
	}
	
	@Override
	public void add(Book book) {
		bookList.add(book);
	}

	@Override
	public void remove(String isbn) {
		Book b = searchByIsbn(isbn);
		if(b!= null) bookList.remove(b);
	}
	

	@Override
	public Book[] getList() {
		//return bookList.toArray(new Book[bookList.size()]);
		return bookList.toArray(new Book[bookList.size()]);
	}

	@Override
	public Book searchByIsbn(String isbn) {
		for(Book b: bookList) {
			if(b.getIsbn().equals(isbn)) return b;
		}
		return null;
	}

	@Override
	public Book[] searchByTitle(String title) {
		List<Book> tmp = new ArrayList<>();
	
		for(Book b: bookList) {
			if(b.getTitle().contains(title)) {
				tmp.add(b);
			}
		}
		return tmp.toArray(new Book[0]);
	}

	@Override
	public Magazine[] getMagazines() {
		List<Book> tmp = new ArrayList<>();
		for(Book b: bookList) {
			if(b instanceof Magazine) {
				tmp.add(b);
			}
		}
		return tmp.toArray(new Magazine[0]);
	}

	@Override
	public Book[] getBooks() {

		List<Book> tmp = new ArrayList<>();
		
		for(Book b: bookList) {
			
			if(!(b instanceof Magazine)) {
				tmp.add(b);
			}
		}

		return tmp.toArray(new Book[0]);
	}

	@Override
	public int getTotalPrice() {
		int total = 0;
		for(Book b: bookList) {
			total += b.getPrice();
		}
		
		return total;
	}

	@Override
	public double getPriceAvg() {
		return (double)getTotalPrice()/bookList.size();
	}
	//코드를 작성해주세요. 

	@Override
	public void buy(String isbn, int quantity) {
	}

	@Override
	public void sell(String isbn, int quantity) {
	}
}
