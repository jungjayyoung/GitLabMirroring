package e1_greedy.q3;

import java.io.*;
import java.util.*;

//Main_bj_1439_뒤집기
public class 문자열뒤집기_김태현 {
	public static void main(String[] args) throws Exception {
//		System.setIn(new FileInputStream("res/input_ect_11_3.txt"));
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		
		char[] ch = in.readLine().toCharArray();
		int flips = 0;
		for(int i=1;i<ch.length;i++) {
			if(ch[i-1] != ch[i] ) {
				flips++;
			}
		}
		System.out.println(++flips/2);
		in.close();
	}
}
/*
0001100
11111
00000001
11001100110011000001
11101101

1
0
1
4
2
*/