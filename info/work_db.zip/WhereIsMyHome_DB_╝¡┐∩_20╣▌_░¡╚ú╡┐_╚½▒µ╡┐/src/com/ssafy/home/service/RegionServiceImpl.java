package com.ssafy.home.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.home.dao.RegionDao;
import com.ssafy.home.dao.RegionDaoImpl;
import com.ssafy.home.dto.RegionDto;

public class RegionServiceImpl implements RegionService {
	private static RegionService instance = new RegionServiceImpl();
	private RegionServiceImpl() {}
	
	public static RegionService getInstance() {
		return instance;
	}
	
	private RegionDao dao = RegionDaoImpl.getInstance();

	@Override
	public void insert(RegionDto dto) throws SQLException {
		dao.insert(dto);

	}

	@Override
	public List<RegionDto> selectAll() throws SQLException {
		return dao.selectAll();
	}

	@Override
	public RegionDto select(int id) throws SQLException {
		return dao.select(id);
	}

	@Override
	public void update(RegionDto dto) throws SQLException {
		dao.update(dto);
	}

	@Override
	public void delete(int id) throws SQLException {
		dao.delete(id);

	}

}
