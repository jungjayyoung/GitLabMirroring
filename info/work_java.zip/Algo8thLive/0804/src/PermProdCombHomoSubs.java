import java.util.Arrays;

public class PermProdCombHomoSubs {

	
	static int N = 4, R = 3, C;
	static int[] a = {1,2,3,4};
	static boolean[] v = new boolean[N];
	static int[] b = new int[R];
	
	
	
	
	public static void main
	(String[] args) {
		
//		C = 0;
//		perm(0); // 중복 비허용 순열
//		System.out.println(C);
//		System.out.println();
		
//		C = 0;
//		prod(0); // 중복 순열
//		System.out.println(C);
//		System.out.println();
		
//		C = 0;
//		comb(0,0); // 4C3 조합(combination): 순서 미중요, 중복 비허용
//		System.out.println(C);
//		System.out.println();
		
//		C = 0;
//		homo(0,0); // 4H3 중복조합(homogeneous): 순서 미중요, 중복 비허용
//		System.out.println(C);
//		System.out.println();
		
		C = 0;
		subs(0); // 2^n 부분집합(subset)
		System.out.println(C);
		System.out.println();
		
	}
	
	static void perm(int cnt) {
		
		if(cnt >= R) {
			
			C++;
			for(int i = 0; i <R;i++) {
				System.out.print(b[i] + " ");
			}
			System.out.println();
			
			return;
		}
		
		for(int i=0; i<N;i++) {
			
			if(v[i]) continue;
			
			v[i] = true;
			b[cnt] = a[i];
			perm(cnt + 1);
			v[i] =false;
			
		}
		
	}
	
	static void prod(int cnt) {
		
		if(cnt >= R) {
			
			C++;
			for(int i = 0; i <R;i++) {
				System.out.print(b[i] + " ");
			}
			System.out.println();
			
			return;
		}
		
		for(int i=0; i<N;i++) {
			b[cnt] = a[i];
			prod(cnt + 1);
		}
		
	}

	static void comb(int cnt,int start) {
		if(cnt >= R) {
			C++;
			for(int i = 0; i <R;i++) {
				System.out.print(b[i] + " ");
			}
			System.out.println();
			
			return;
		}
		
		for(int i=start; i<N;i++) {
			
			if(v[i]) continue;
			
			v[i] = true;
			b[cnt] = a[i];
			comb(cnt + 1,i + 1);
			v[i] =false;
		}
	
	
	}

	static void homo(int cnt,int start) {
		if(cnt >= R) {
			
			C++;
			for(int i = 0; i <R;i++) {
				System.out.print(b[i] + " ");
			}
			System.out.println();
			
			return;
		}
		
		for(int i=start; i<N;i++) {
			b[cnt] = a[i];
			homo(cnt + 1,i);
		}

	}
	
	static void subs(int depth) {
		if(depth >= N) {
			
			C++;
			//System.out.println(Arrays.toString(v));

			for(int i = 0; i <N;i++) {
				System.out.print(v[i]?a[i]:"X");
			}
			System.out.println();
			return;
		}
		
		v[depth]  =true;
		subs(depth + 1);
		v[depth] = false;
		subs(depth + 1);
		
	}
}
