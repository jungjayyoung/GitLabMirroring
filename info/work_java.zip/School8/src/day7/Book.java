package day7;

import java.io.Closeable;
import java.io.Serializable;

//Serializable : 객체를 직렬화 할 때 사용
public class Book implements  Comparable<Book>{

	String isbn;
	String title;
	int price;
	
	public Book(String isbn, String title, int price) {
		this.isbn = isbn;
		this.title = title;
		this.price = price;
	}
	
	@Override
	public String toString() {
		return isbn + "/" + title + "/" + price;
	}

	// 정수 정렬
//	@Override
//	public int compareTo(Book o) {
//		
//		
//		
//		// 정렬할 때는 항상 this.price가 가 앞으로 파라미터가 뒤로 가야한다.
//		// 역순으로 바꾸고 싶으면 순서를 바꾸거나, 
//		//앞에 -를 붙인다. <- 일단 이걸 쓰도록 하자
//		return Integer.compare(price, o.price); 
//	}
	
	//문자열 정렬
	@Override
	public int compareTo(Book o) {
		
		return isbn.compareTo(o.isbn); 
		// 역순으로 하려면 아래처럼 하거나 앞에 -를 붙인다.
		//return o.isbn.compareTo(isbn); 
	}
	
	
	
	
}
