package com.ssafy.live3.inter;

public interface Fightable {

	int fire();
	
	
}
