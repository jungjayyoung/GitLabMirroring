
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



@WebServlet("/EmpServlet")
public class EmpServlet extends HttpServlet {
	
	String driver = "com.mysql.cj.jdbc.Driver";		
	String url = "jdbc:mysql://localhost:3306/scottdb?characterEncoding=UTF-8&serverTimezone=UTC";		
	String user = "scott";
	String password = "tiger";		
	String query = "select empid, fname, email from emp where deptid = 50 order by empid";

	@Override
	public void init() throws ServletException {
		//1.Driver 등록-사용할 db 등록
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			
			response.setContentType("text/html;charset=utf-8");		
			PrintWriter out = response.getWriter();			
			
			
			//2. Connection 생성 - network 연결
			Connection con = DriverManager.getConnection(url, user, password);
			
			//3.Statement  생성
			Statement stat = con.createStatement();
			
			//4.Query  실행
			ResultSet rs = stat.executeQuery(query);		
			out.println("<center><h1>Employee Data</data>");
			out.println("<table border='1'>");
			
			//5. 결과 처리
			while(rs.next() == true) {
				int empid = rs.getInt(1);
				String fname = rs.getString("fname");
				String email = rs.getString(3);
				
				out.println("<tr><td>"+ empid + "</td><td>" + fname + "</td><td>" + email+ "</td></tr>");
				
			}
			out.println("</table></center>");
			
			//6. 마무리
			rs.close();
			stat.close();
			con.close();
		
		}catch(Exception e) {
			e.printStackTrace();
		}		
	}
}
