package com.ssafy.ws.step2;

public class ArrayTest {
	public static void main(String[] args) {
		// 코드를 작성하세요.
	}
}
