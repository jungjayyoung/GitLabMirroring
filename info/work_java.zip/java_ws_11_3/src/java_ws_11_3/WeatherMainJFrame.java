package java_ws_11_3;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;

//기상청 날씨누리 https://www.weather.go.kr
public class WeatherMainJFrame extends JFrame{
	WeatherDAOSAX dao = WeatherDAOSAX.getInstance();
	//WeatherDAODOM dao = WeatherDAODOM.getInstance();

	JList<String> jlist = new JList<>();
	JButton button = new JButton("가져오기");
	DefaultListModel<String> model = new DefaultListModel<>();

	public void createGUI() {
		setTitle("날씨 정보");
		jlist.setSize(500,  300);
		jlist.setModel(model);
		this.add(jlist, BorderLayout.CENTER);
		this.add(button, BorderLayout.SOUTH);

		addEvent();

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(500, 500);
		setVisible(true);
	}
	public void addEvent() {
		button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dao.connectXML();
				List<Weather> list = dao.getWeatherList();
				showList(list);
			}
		});
	}
	public void showList(List<Weather> list) {
		model.removeAllElements();
		for(int i=0; i<list.size(); i++) {
			model.addElement(list.get(i).toString());
		}
	}
	public static void main(String[] args) {
		WeatherMainJFrame wm = new WeatherMainJFrame();
		wm.createGUI();
	}
}
