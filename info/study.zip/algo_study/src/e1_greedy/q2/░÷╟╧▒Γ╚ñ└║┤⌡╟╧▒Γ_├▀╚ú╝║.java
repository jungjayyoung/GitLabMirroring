package 곱하기혹은더하기;

import java.io.BufferedReader;
import java.io.FileReader;

public class 곱하기혹은더하기_추호성 {

	public static void main(String[] args) throws Exception {
		// read file and init
		BufferedReader bf = new BufferedReader(new FileReader("C:/SSAFY/algo_study/1_그리디_기출/src/곱하기혹은더하기/곱하기혹은더하기.txt"));
		char[] arr = bf.readLine().toCharArray();
		long result = arr[0] - '0';

		// algo
		for (int i = 0; i < arr.length - 1; i++) {
			result = (result * (arr[i + 1] - '0') > result + (arr[i + 1] - '0')) ? result * (arr[i + 1] - '0')
					: result + (arr[i + 1] - '0');
		}

		System.out.println(result);
		bf.close();
	}

}
