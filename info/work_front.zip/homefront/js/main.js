window.onload = function () {
  if (!document.querySelector(".content-user-list")) return;

  const xhr = new XMLHttpRequest();
  const method = "GET";
  const url = "data/user.json";

  xhr.open(method, url);
  xhr.setRequestHeader("Content-Type", "application/text");

  xhr.onreadystatechange = function () {
    if (xhr.readyState === xhr.DONE) {
      if (xhr.status === 200) {
        const resJson = JSON.parse(xhr.responseText);
        const userData = resJson.users;
        let userList = document.querySelector(".content-user-list");
        for (let i = 0; i < userData.length; i++) {
          let carItem = `
            <div class="col-5">
              <div class="card border-danger mb-3 ms-4 me-4 position-relative">
                <div class="row g-0">
                  <div class="col-md-4 mt-2 ps-2 mb-2">
                    <img src="${userData[i]["img"]}" class="img-fluid rounded-start" alt="..." />
                  </div>
                  <div class="col-md-8 mt-5">
                    <div class="card-body">
                      <h5 class="card-title">${userData[i]["id"]}</h5>
                      <h6>${userData[i]["name"]}</h6>
                      <h6>${userData[i]["email"]}</h6>
                      <h6 class="mb-3">${userData[i]["age"]} 세</h6>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            `;
          userList.innerHTML += carItem;
        }
      }
    }
  };

  xhr.send();
};

function regist() {
  let id = document.getElementById("id").value;
  let password = document.getElementById("password").value;
  let name = document.getElementById("name").value;
  let address = document.getElementById("address").value;
  let tel = document.getElementById("tel").value;

  if (!id || !password || !name || !address || !tel) {
    alert("빈칸이 없도록 입력해주세요.");
    return;
  } else {
    const user = {
      id: id,
      password: password,
      name: name,
      address: address,
      tel: tel,
    };

    localStorage.setItem("user", JSON.stringify(user));
    alert("사용자 등록 성공!");
    window.location.replace("login.html");
  }
}

function login() {
  let id = document.getElementById("id").value;
  let password = document.getElementById("password").value;

  const user = JSON.parse(localStorage.getItem("user"));

  if (user && user.id && user.password && user.id === id && user.password === password) {
    alert("로그인 성공 !");

    document.querySelector("#login").setAttribute("style", "display: none");
    document.querySelector("#logout").setAttribute("style", "display: block");
    window.location.replace("index.html");
  } else {
    alert("로그인 실패 !");
  }
}

// 회원 정보 가져오기
function user_info() {
  const user = JSON.parse(localStorage.getItem("user"));
  let id = user.id;
  let password = user.password;
  let name = user.name;
  let address = user.address;
  let telnum = user.tel;
}

// 회원 정보창 열기
function userinfoMake() {
  window.open("user.html", "userinfo", "width=500,height=400,top=300,left=400");
}
