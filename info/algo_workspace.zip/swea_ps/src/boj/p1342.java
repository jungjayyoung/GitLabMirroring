package boj;

import java.io.*;
import java.util.*;


public class p1342 {

	static char[] c; 
	static String s;
	static int[] visited;
	static int cntt = 0;
	
	public static void main(String[] args) throws IOException{
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		s = br.readLine();
		c = s.toCharArray();
		visited = new int[s.length()];
		
		
		
		
		System.out.println(cntt);
	}
	
	static boolean nextPermutation(char[] str) {
		
		int i = s.length() - 1;
		
		while(i > 0 && s.charAt(i-1) >= s.charAt(i)) i--;
		
		if(i == 0) {
			return false;
		}
		
		int j = s.length() - 1;
		while(s.charAt(i-1) >= s.charAt(j)) j--;
		
		int k = s.length() - 1;
		
		while(i < k) swap(str,i++,k--);
		
		return true;
		
	}
	
	public static void swap(char[] c,int i, int j) {
		
		char tmp = c[i]; c[i] = c[j]; c[j] = tmp;
		
	}

}
