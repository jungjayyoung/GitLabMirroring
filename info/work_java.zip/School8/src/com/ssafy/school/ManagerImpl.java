package com.ssafy.school;

import java.util.Arrays;

public class ManagerImpl implements IManager {

	private Person[] pa;
	private int index;
	
	
	
	public ManagerImpl(int size) {
		pa = new Person[size];
	}
	public ManagerImpl() {
		this(10);
	}
	
	@Override
	public void add(Person p) {
		pa[index++] = p;
	}
	@Override
	public Person[] search() {
		return Arrays.copyOf(pa, index);
	}
	
	@Override
	public Person search(String name) {
		for(int i=0; i < index;i++) { //pa.length를 하게 되면 NullPointerException 이 터진다.
			String nm = pa[i].getName();
			if(nm.equals(name)) return pa[i];
		}
		return null;
	}
	
	@Override
	public void update(Person p) {
		for(int i=0; i < index;i++) { //pa.length를 하게 되면 NullPointerException 이 터진다.
			
			if(pa[i].getName().equals(p.getName())) {
				pa[i] =p;
				return;
			}
		}
	}
	
	@Override
	public void delete(String name) {
		for(int i=0; i < index;i++) { //pa.length를 하게 되면 NullPointerException 이 터진다.
			
			if(pa[i].getName().equals(name)) {
				
				pa[i] = pa[--index];
				return;
			}
		}
	}
	
	@Override
	public void printAll() {
		for(int i = 0; i<index;i++) {
			pa[i].printAll();
		}
	}
	
}
