package com.ssafy.live3.generic.box;

public class NormalBox {
	private Object some;

	public NormalBox() {}
	
	public Object getSome() {
		return some;
	}

	public void setSome(Object some) {
		this.some = some;
	}

	public NormalBox(Object some) {
		this.some = some;
	}
	
	
}
