package com.ssafy.live2;

import java.io.BufferedInputStream;
import java.util.List;
import java.util.Scanner;

public class ImportTest {

	BufferedInputStream bi;
	
	Scanner s;
	//ctrl + shift + o : 자동으로 import해준다
	List list;
	// 이름이 충돌할 때는 이렇게 앞에를 다 써야한다.
	java.awt.List list2;
}
