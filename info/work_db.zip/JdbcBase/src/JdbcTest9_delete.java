import java.sql.*;



public class JdbcTest9_delete {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		String sql ="select * from regions where region_id=?";

		try(Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/ssafydb?serverTimezone=UTC", "ssafy", "ssafy");
				PreparedStatement ps = con.prepareStatement(sql);) {
			con.setAutoCommit(false);
			ps.setInt(1, 3);
			int r = ps.executeUpdate();
					
			while(rs.next()) {
				System.out.println("삭제 완료");
			}
			if(rs != null) rs.close();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
	}
}
