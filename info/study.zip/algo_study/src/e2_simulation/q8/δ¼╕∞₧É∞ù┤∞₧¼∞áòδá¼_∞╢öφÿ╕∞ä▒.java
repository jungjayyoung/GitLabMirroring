package 문자열재정렬;

import java.io.BufferedReader;
import java.io.FileReader;

public class 문자열재정렬_추호성 {

	public static void main(String[] args) throws Exception {
		BufferedReader bf = new BufferedReader(
				new FileReader("C:\\SSAFY\\algo_study\\2_구현_기출\\src/럭키스트레이트/럭키스트레이트.txt"));
		char[] arr = bf.readLine().toCharArray();
		int result = 0;

		for (int i = 0; i < arr.length / 2; i++)
			result += (arr[i] - '0');

		for (int i = arr.length / 2; i < arr.length; i++)
			result -= (arr[i] - '0');

		if (result == 0)
			System.out.println("LUCKY");

		else
			System.out.println("READY");

		bf.close();

	}

}
