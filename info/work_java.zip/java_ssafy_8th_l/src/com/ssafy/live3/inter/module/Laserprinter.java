package com.ssafy.live3.inter.module;

public class Laserprinter implements Printer{

	@Override
	public void print(String fileName) {
		System.out.println("lazer printer: " + fileName);
	}
	
	

}
