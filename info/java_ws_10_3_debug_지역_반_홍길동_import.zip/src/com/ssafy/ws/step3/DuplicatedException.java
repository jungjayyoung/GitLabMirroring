package com.ssafy.ws.step3;

public class DuplicatedException extends Exception {
	
	public DuplicatedException() {
		this("중복 등록입니다.");
	}

	public DuplicatedException(String msg) {
		super(msg);
		
	}


}
