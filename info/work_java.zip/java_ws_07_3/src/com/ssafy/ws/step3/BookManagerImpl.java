package com.ssafy.ws.step3;

import java.util.Arrays;

/**
 * 도서리스트를 배열로 유지하며 관리하는 클래스
 */
public class BookManagerImpl implements IBookManager {

	
	private static int MAX_SIZE=100;
	private Book[] books=new Book[MAX_SIZE];
	private int size;
	
	private static IBookManager instance = BookManagerImpl.getInstance();
	private BookManagerImpl() {}
	public static IBookManager getInstance() {
		return instance;
	}
	
	@Override
	public void add(Book book) {
		books[size++] = book;
	}

	@Override
	public void remove(String isbn) {
		for(int i = 0; i < size; i++) {
			
			if(books[i].getIsbn().equals(isbn)) {
				books[i] = books[--size];
				books[size] = null;
				return;
			}
			
		}
	}

	@Override
	public Book[] getList() {
		return Arrays.copyOf(books, size);
	}

	@Override
	public Book searchByIsbn(String isbn) {
		for(int i = 0; i < size; i++) {
			
			if(books[i].getIsbn().equals(isbn)) {
				return books[i];
			}
			
		}
		return null;
	}

	@Override
	public Book[] searchByTitle(String title) {
		Book[] tmp = new Book[size];
		int cnt =0;
		for(int i = 0; i < size; i++) {
			
			if(books[i].getTitle().contains(title)) {
				tmp[cnt++] = books[i];
			}
			
		}
		return Arrays.copyOf(tmp, cnt);
	}

	@Override
	public Magazine[] getMagazines() {
		Magazine[] tmp = new Magazine[size];
		int cnt =0;
		for(int i = 0; i < size; i++) {
			
			if(books[i] instanceof Magazine) {
				tmp[cnt++] = (Magazine)books[i];
			}
			
			
		}
		return Arrays.copyOf(tmp, cnt);
	}

	@Override
	public Book[] getBooks() {
		Book[] tmp = new Book[size];
		int cnt =0;
		for(int i = 0; i < size; i++) {
			
			if(!(books[i] instanceof Magazine)) {
				tmp[cnt++] = books[i];
			}
			
		}
		return Arrays.copyOf(tmp, cnt);
	}

	@Override
	public int getTotalPrice() {
		int total = 0;
		for(int i = 0; i< size; i++) {
			
			total += books[i].getPrice();
			
		}
		
		return total;
	}

	@Override
	public double getPriceAvg() {
		return getTotalPrice()/(double)size;
	}
	//코드를 작성해주세요. 
}
