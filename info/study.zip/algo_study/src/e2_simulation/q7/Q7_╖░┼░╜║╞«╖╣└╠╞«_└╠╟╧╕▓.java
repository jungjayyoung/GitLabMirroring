package coding.implementation;

import java.io.*;
public class Main_Q7_럭키스트레이트_이하림 {
	
	//18406
	public static void main(String[] args) throws IOException {
		
		BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
		char[] c = bf.readLine().toCharArray();
		
		int lSum = 0;
		int rSum = 0;
		
		for(int i=0;i<c.length/2;i++) {
			lSum += c[i] - '0';
			rSum += c[c.length-1-i] - '0';
		}
		if(lSum == rSum) System.out.print("LUCKY");
		else System.out.print("READY");
	}

}
