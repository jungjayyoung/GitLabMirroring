package p1974;

import java.util.Scanner;

public class p1974 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	}
}
