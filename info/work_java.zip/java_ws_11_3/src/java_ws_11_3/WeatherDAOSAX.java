package java_ws_11_3;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class WeatherDAOSAX {
	private List<Weather> list;

	private static WeatherDAOSAX instance = new WeatherDAOSAX();
	private WeatherDAOSAX() {
	}
	public static WeatherDAOSAX getInstance() {
		return instance;
	}

	public void connectXML(){
		String url = "http://www.kma.go.kr/wid/queryDFSRSS.jsp?zone=1168064000";//서울시 감남구 역삼1동
		try {
			SAXParserFactory factory=SAXParserFactory.newInstance();
			SAXParser parser=factory.newSAXParser();
			parser.parse(url,new SAXHandler());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public List<Weather> getWeatherList(){
		return list;
	}
	class SAXHandler extends DefaultHandler {
		private StringBuilder sb;
		Weather w;

		@Override
		public void startDocument() throws SAXException{
			list=new ArrayList<Weather>();
			sb=new StringBuilder();
		}
		@Override
		public void startElement(String uri, String localName, String name, Attributes attributes) throws SAXException{
			if(name.equalsIgnoreCase("data")){
				w=new Weather();
			}
		}
		@Override
		public void characters(char[] ch, int start, int length) throws SAXException {
			sb.append(ch, start, length);
		}
		@Override
		public void endElement(String uri, String localName, String name) throws SAXException {
			if(w!=null){
				
				//작성하세요...
				if(name.equals("hour")) {
					w.setHour(Integer.valueOf(sb.toString().trim()));
				}else if(name.equals("temp")){
					w.setTemp(Double.valueOf(sb.toString().trim()));
				}else if(name.equals("wfKor")){
					w.setWfKor(sb.toString().trim());
				}else if(name.equals("reh")){
					w.setReh(Integer.valueOf(sb.toString().trim()));
				}else if(name.equals("data")) {
					list.add(w);
				}
				
			}
			
			sb.setLength(0);
		}
	}
}
