import java.sql.*;



public class JdbcTest2_insert {

	public static void main(String[] args) throws Exception{
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		String sql ="insert into regions values(?,?)";
		Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/ssafydb?serverTimezone=UTC", "ssafy", "ssafy");
		PreparedStatement ps = con.prepareStatement(sql);
		
		ps.setInt(1, 5);
		ps.setString(2, "Ssafy");
		int r = ps.executeUpdate();
		System.out.println("등록완료" + r);
		
		
		
		ps.close();
		con.close();
	}
}
