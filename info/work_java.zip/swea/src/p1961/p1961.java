package p1961;

import java.util.Scanner;

public class p1961 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int T = sc.nextInt();
		
		for(int i = 1; i <= T; i++) {
			
			int n = sc.nextInt();
			
			int [][] arr = new int [n][n]; 
			int [][] copy_arr = new int [n][n]; // arr 을 복사할 배열 
			int[] col = new int[n];
			int[] row = new int[n];
			
			
			// arr을 입력값으로 초기화하기!!
			for(int y = 0 ; y < n; y++) {
				for(int x = 0; x < n;x++) {
					arr[y][x] = sc.nextInt(); 
				}
			}
			
			copy_arr = arr;
			
			
			// 90도 회전
			for(int y =0; y<n;y++) {
				
				for(int x = 0; x < n; x++) {
					
					
				}
			}
			
		}

	}

}
