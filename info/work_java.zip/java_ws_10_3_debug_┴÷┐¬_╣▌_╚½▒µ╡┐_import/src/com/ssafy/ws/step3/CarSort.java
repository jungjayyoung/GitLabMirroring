package com.ssafy.ws.step3;

import java.io.*;
import java.util.*;

public class CarSort {
	public static void main(String[] args) {
		int[] ia={22,11,33};
		System.out.println(Arrays.toString(ia));
		Arrays.sort(ia);
		System.out.println(Arrays.toString(ia));
		System.out.println();
		
		List<Integer> il=new ArrayList<>();
		il.add(22);
		il.add(11);
		il.add(33);
		System.out.println(il);
		Collections.sort(il);
		System.out.println(il);
		System.out.println();
	}
}
