# 1. world 데이터베이스를 사용하도록 설정하시오.
use world;

# 2. city, country, countrylanguage 테이블의 구조를 파악하시오.
select * from city;
desc city;

# 3. country table에서 code가 KOR인 모든 자료를 조회하시오.
select *
from country
where code ='KOR';

# 4. country에서 gnp 변동량(gnp-gnpold)이 양수인 국가에 대해 gnp 변동량의 오름차순으로 정렬하시오.(115건)
select name, gnp, gnpold, gnp-gnpold as '변동량'
from country
where gnp-gnpold > 0
order by gnp-gnpold asc;

# 5. country table에서 continent를 중복 없이 조회하시오. continent의 길이로 정렬한다.(7건)
select distinct continent
from country
order by length(continent);

# 6. country에서 asia 대륙에 속하는 국가들의 정보를 아래와 같이 출력하시오. name으로 정렬한다.(51건)
select concat(name, cast("은 " as char), region, cast("속하는 인구는 " as char), population, cast("명이다." as char)) as "정보"
from country
where continent = 'Asia'
order by name;

# 7. country에서 독립 년도에 대한 기록이 없고 인구가 10000이상인 국가의 정보를 인구의 오름차순으로 출력하시오.(29건)
select * from country where population >= 10000 and indepyear is null order by population;

# 8. country에서 인구가 1억<=x<=2억 인 나라를 인구 기준으로 내림차순 정렬해서 상위 3개만 출력하시오.
select code, name, population pop from country where population between 100000000 and 200000000 order by pop desc limit 3;

# 9. country에서 800, 1810, 1811, 1901에 독립한 나라를 독립년 기준으로 오름차순 출력하시오. 단 독립 년이 같다면 code를 기준으로 내림차순 한다.(7건)
select code, name, indepyear from country where indepyear in(800,1810,1811,1901)
order by indepyear asc, code desc;

# 10. country에서 region에 asia가 들어가고 name의 두 번째 글자가 o인 정보를 출력하시오.(4건)
select * from country where region like '%asia%' and substr(name,2,1) = 'o';
select * from country where region like '%asia%' and name like '_o%';

# 11. '홍길동'과 'hong'의 글자 길이를 각각 출력하시오.
select char_length('홍길동'), char_length('hong');

# 12. country에서 governmentform에 republic이 들어있고 name의 길이가 10 이상인 자료를 name 길이의 내림차순으로 상위 10개만 출력하시오.(10건)
select * from country where GovernmentForm like '%republic%' and char_length(name) >= 10 order by name desc limit 10;

# 13. country에서 code가 모음으로 시작하는 나라의 정보를 출력하시오. 이때 name의 오름차순으로 정렬하고 3번 부터 3개만 출력한다.
select * from country where Code like 'A%' or 'E%' or 'I%' or 'O%' or 'U%' order by name asc limit 2, 3; 
select * from country where Code Rlike  '^[aeiouAEIOU.*]' order by name asc limit 2, 3; 
select * from country where substr(code,1,1) in ('a','e','i','o','u') order by name asc limit 2, 3; 
# 14. country에서 name을 맨 앞과 맨 뒤에 2글자를 제외하고 나머지는 *로 처리해서 출력하시오.(239건)

select concat(rpad(left(name,2), char_length(name) - 2,'*'), right(name,2)) from country;

# 15. country에서 region을 중복 없이 가져오는데 공백을 _로 대체하시오. region의 길이로 정렬한다.(25건)
select distinct(replace(region,' ','_')) from country order by char_length(region);

# 16. country에서 인구가 1억 이상인 국가들의 1인당 점유면적(surfacearea/population)을 반올림해서 소숫점 3자리로 표현하시오. 1인당 점유 면적의 오름차순으로 정렬한다.(10건)
select round((surfacearea/population),3) from country where population >= 100000000 order by (surfacearea/population) asc;
