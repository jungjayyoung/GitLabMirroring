package bj;
import java.io.*;
import java.util.*;

class Pair(){
    String s;
    Integer cnt;
    
    public Pair(String s, Integer cnt){
        this.s = s;
        this.cnt = cnt;
    }
    
    public String gets(){
        return s;
    }
    
    public Integer getc(){
        return cnt;
    }

}
public class test {

	public int solution(String s) throws IOException{
        int answer = 1000000;
        BufferedReader br =  new BufferedReader(new InputStreamReader(System.in));
        int s_size = s.length();
        String s = br.readLine();
        
        
        for(int i =1; i<= s_size/2;i++){
            List<Pair<String,Integer>> pairs = new ArrayList<>();
            int slice_size = i;
            String tmp = "";
            int idx = 0;
            for(int j = 0; j < s.length(); j += slice_size){
                
                for(int k =j; k < j + slice_size; k++){
                    tmp = tmp + s.charAt(k);
                }
                if(idx - 1 >= 0){
                    if()
                }
                pairs.add(new Pair<>(tmp,i));
                idx++;
                
            }
            
        }
        
       
        

}

	
	
