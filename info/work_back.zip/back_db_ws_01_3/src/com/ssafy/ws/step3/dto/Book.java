package com.ssafy.ws.step3.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Book {
	private String isbn;
	private String title;
	private String author;
	private int price;
	private String desc;
}
