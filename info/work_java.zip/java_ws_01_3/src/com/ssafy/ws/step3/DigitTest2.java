package com.ssafy.ws.step3;

/**
 * 모래시계 모양의 숫자 출력하는 클래스
 */
public class DigitTest2 {

	public static void main(String[] args) {
		
		
		int num = 1;
		
		for(int i = 0; i < 3; i++) {
			
			for(int j = 5- i; j < 5;j++) {
				System.out.printf("   ");
			}
			
			for(int j = 5 - i; j > i; j--) {
				System.out.printf("%3d",num++);
			}
			
			for(int j = 5- i; j < 5;j++) {
				System.out.printf("   ");
			}
			
			System.out.println();
			
		}
		
		for(int i = 1; i >= 0; i--) {
			
			for(int j = 5- i; j < 5;j++) {
				System.out.printf("   ");
			}
			
			for(int j = 5 - i; j > i; j--) {
				System.out.printf("%3d",num++);
			}
			
			for(int j = 5- i; j < 5;j++) {
				System.out.printf("   ");
			}
			
			System.out.println();
			
		}

	}
}
