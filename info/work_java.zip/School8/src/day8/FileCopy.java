package day8;

import java.io.*;

public class FileCopy {

	public static void main(String[] args) throws Exception{
		//"FileCopy.java" -> "out.txt"
//		System.setIn(new FileInputStream("res/input_d1_1245.txt"));
//		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		try(BufferedReader br = new BufferedReader(
								new InputStreamReader(
								new FileInputStream("src/day8/FileCopy.java")
						)
				);
				PrintWriter pw = new PrintWriter(
						new BufferedWriter(
								new OutputStreamWriter(
										new FileOutputStream("src/day8/out.txt")
										)
								)
						);
				)
		 {
			String line = null;
			while((line = br.readLine()) != null) {
				//System.out.println(line);
				//bw.write(line);
				//bw.newLine();
				//bw.flush();
				pw.println(line);
				pw.flush();
			}
			System.out.println("filr copy ok");
			
		}catch(IOException e) {
			e.printStackTrace();
		}
	}

}
