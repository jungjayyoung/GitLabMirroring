package com.ssafy.live2.extend.person;

public class Spider {

	void jump() {
		System.out.println("어마어마하게 높은 점프 가능");
	}
	
	
	void fireWeb() {
		System.out.println("거미줄 쉭쉭~~");
		
	}
}
