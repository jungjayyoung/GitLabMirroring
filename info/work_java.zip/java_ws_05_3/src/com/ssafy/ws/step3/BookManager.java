package com.ssafy.ws.step3;

import java.util.Arrays;

public class BookManager {
	private static int MAX_SIZE=100;
	private Book[] books=new Book[MAX_SIZE];
	private int size;
	
	private static BookManager instance = new BookManager();
	private BookManager() {}
	public static BookManager getInstance() {
		return instance;
	}
	
	
	
	public void add(Book book) {
		books[size++] = book;
	}
	public void remove(String isbn) {
		for(int i = 0; i < size; i++) {
			
			if(books[i].getIsbn().equals(isbn)) {
				books[i] = books[--size];
				books[size] = null;
				return;
			}
			
		}

	}
	public Book[] getList() {
		//return Arrays.copyOfRange(books, 0, size);
		return Arrays.copyOf(books, size);
	}
	public Book searchByIsbn(String isbn) {
		for(int i = 0; i < size; i++) {
			
			if(books[i].getIsbn().equals(isbn)) {
				return books[i];
			}
			
		}
		return null;
	}
}
