package day7;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ComparableSort {

	public static void main(String[] args) {

		int[] ia = {123,987,456};
		System.out.println(Arrays.toString(ia));
		Arrays.sort(ia);
		System.out.println(Arrays.toString(ia));
		
		
		Book[] ba = {
				new Book("123","자바",2000),
				new Book("987","알고",1000),
				new Book("456","가곡",3000),
		};
		System.out.println(Arrays.toString(ba));
		//Arrays.sort(ba);// ClassCastException: java.lang.Comparable
		//아래처럼 내림차순으로 정렬할 수 있다.
		//Arrays.sort 사용
		Arrays.sort(ba,Comparator.reverseOrder());// ClassCastException: java.lang.Comparable
		System.out.println(Arrays.toString(ba));
		
		
		// 리스트는 어떻게 정렬할까?
		// Collections.sort 사용
		List<Book> bl = new ArrayList<>();
		bl.add(new Book("123","자바",2000));
		bl.add(new Book("987","알고",1000));
		bl.add(new Book("456","가곡",3000));
		System.out.println(bl);
		
		Collections.sort(bl,Comparator.reverseOrder());
		System.out.println(bl);
		
	}

}
