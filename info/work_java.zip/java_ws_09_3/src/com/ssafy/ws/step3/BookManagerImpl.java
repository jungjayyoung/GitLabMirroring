package com.ssafy.ws.step3;

import java.util.ArrayList;
import java.util.List;


/**
 * 도서리스트를 컬렉션으로 유지하며 관리하는 클래스
 */
public class BookManagerImpl implements IBookManager {
	private static int MAX_SIZE=100;
	private List<Book> bookList = new ArrayList<>();
	
	
	private BookManagerImpl() {}
	private static IBookManager instance = new BookManagerImpl();
	
	public static IBookManager getInstance() {
		return instance;
	}
	
	@Override
	public void add(Book book) {
		bookList.add(book);
	}

	@Override
	public void remove(String isbn) {
		Book b = searchByIsbn(isbn);
		if(b!= null) bookList.remove(b);
	}
	

	@Override
	public Book[] getList() {
		//return bookList.toArray(new Book[bookList.size()]);
		return bookList.toArray(new Book[bookList.size()]);
	}

	@Override
	public Book searchByIsbn(String isbn) {
		for(Book b: bookList) {
			if(b.getIsbn().equals(isbn)) return b;
		}
		return null;
	}

	@Override
	public Book[] searchByTitle(String title) {
		List<Book> tmp = new ArrayList<>();
	
		for(Book b: bookList) {
			if(b.getTitle().contains(title)) {
				tmp.add(b);
			}
		}
		return tmp.toArray(new Book[0]);
	}

	@Override
	public Magazine[] getMagazines() {
		List<Book> tmp = new ArrayList<>();
		for(Book b: bookList) {
			if(b instanceof Magazine) {
				tmp.add(b);
			}
		}
		return tmp.toArray(new Magazine[0]);
	}

	@Override
	public Book[] getBooks() {

		List<Book> tmp = new ArrayList<>();
		
		for(Book b: bookList) {
			
			if(!(b instanceof Magazine)) {
				tmp.add(b);
			}
		}

		return tmp.toArray(new Book[0]);
	}

	@Override
	public int getTotalPrice() {
		int total = 0;
		for(Book b: bookList) {
			total += b.getPrice();
		}
		
		return total;
	}

	@Override
	public double getPriceAvg() {
		return (double)getTotalPrice()/bookList.size();
	}
	//코드를 작성해주세요. 

	@Override
	public void buy(String isbn, int quantity) throws ISBNNotFoundException{
		Book b = searchByIsbn(isbn);
		b.setQuantity(b.getQuantity() + quantity);
	}

	@Override
	public void sell(String isbn, int quantity) throws ISBNNotFoundException, QuantityException{
		Book b = searchByIsbn(isbn);
		if(b==null) throw new ISBNNotFoundException(isbn);
		int r = b.getQuantity() - quantity;
		if(r <0) throw new QuantityException();
		b.setQuantity(r);
	} 
}
