package day5;

import com.ssafy.school.Person;

interface IA{
	
	
}

interface IB{
	
	
}

// 인터페이스 끼리는 다중 상속이 가능하다.
// 인터페이스를 오버라이딩하려면 반드시 public이어야 한다.자동으로 컴파일러가 public abstract를 붙여준다.
interface IFlyer extends IA, IB{
	
	// 생략해도 아래 위로 같다.
	public static final int i = 11;
						int j = 12;
	
	// 생략해도 아래 위로 같다.
	public abstract void fly();
					void land();
					void takeOff();
}

class Airplane implements IFlyer{

	@Override
	public void fly() {
		System.out.println("비행기가 난다");
	}

	@Override
	public void land() {}
	@Override
	public void takeOff() {}
	
	
}

class Bird implements IFlyer{

	@Override
	public void fly() {
		System.out.println("새가 난다");
	}

	@Override
	public void land() {}
	@Override
	public void takeOff() {}
	
	
}


class Superman extends Person implements IFlyer{

	@Override
	public void fly() {
		System.out.println("슈퍼맨이 난다");
	}

	@Override
	public void land() {}
	@Override
	public void takeOff() {}
	
	
}

public class FlyerTest {

	public static void main(String[] args) {
		//IFlyer f = new Bird();
		//f.fly();

		// abstract 클래스는 생성이 불가능하다
		//IFlyer f = new IFlyer();
		//f.fly();
		
		IFlyer[] fa = new IFlyer[3];
		fa[0] = new Airplane();
		fa[1] = new Bird();
		fa[2] = new Superman();
		
		for(IFlyer t:fa) t.fly();
		
		
	}

}
