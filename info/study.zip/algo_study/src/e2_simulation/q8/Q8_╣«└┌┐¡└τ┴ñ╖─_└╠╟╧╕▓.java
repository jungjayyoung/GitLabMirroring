package coding.implementation;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class Main_Q8_문자열재정렬_이하림 {

	public static void main(String[] args) throws IOException {
		
		BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
		char[] c = bf.readLine().toCharArray();
		StringBuilder sb = new StringBuilder();
		Arrays.sort(c);
		
		int sum = 0;
		for(int i=0;i<c.length;i++) {
			if(c[i] < 63) {
				sum += c[i]-'0';
			}
			else sb.append(Character.toString(c[i]));
		}
		if(sum != 0) sb.append(Integer.toString(sum));
		
		System.out.println(sb);
	}
}